#' @export
predict.cqrwenet <- function(object, newx, s = NULL,
                             type = "response", ...)
  NextMethod("predict")


##==============================================================================

predict.cqrwenetpath <- function(object, newx, s = NULL,
                                 type = c("response"), ...) {
  type <- match.arg(type)
  newx <- as.matrix(newx)
  nobsn <- nrow(newx)
  nbeta <- rbind2(object$alpha, object$beta)
  ntaus <- nrow(object$alpha)
  nlam <- ncol(object$alpha)
  if (!is.null(s)) {
    vnames <- dimnames(nbeta)[[1]]
    dimnames(nbeta) <- list(NULL, NULL)
    lambda <- object$lambda
    lamlist <- lambda.interp(lambda, s)
    nbeta <- nbeta[, lamlist$left, drop = FALSE] %*%
      Diagonal(x = lamlist$frac) +
      nbeta[, lamlist$right, drop = FALSE] %*%
      Diagonal(x = 1 - lamlist$frac)
    dimnames(nbeta) <- list(vnames, paste(seq(along = s)))
    nlam <- length(s)
  }
  newx_aug <- cbind(diag(ntaus)[rep(seq(ntaus), each = nobsn), ],
                    do.call(rbind,
                            replicate(ntaus, newx, simplify = FALSE)))
  nfit <- as.matrix(as.matrix(newx_aug) %*% nbeta)
  array(nfit, dim = c(nobsn, ntaus, nlam))
}
