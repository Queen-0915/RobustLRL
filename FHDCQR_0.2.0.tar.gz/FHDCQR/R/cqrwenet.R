##' Regularization paths for weighted lasso and elastic net penalized composite
##' quantile regression
##'
##' Fits regularization paths for (weighted) lasso and elastic net penalized
##' composite quantile regression at a sequence of L1 regularization parameters
##' via the ADMM algorithm.
##'
##' @param x Matrix of predictors, of dimension (\eqn{n} by \eqn{p}). Each row
##'   is an observation.
##' @param y Response variable.
##' @param tau The sequence of quantile levels. A numeric vector whose elements
##'   must be in (0, 1). The elements must have different values. Otherwise,
##'   duplicates will be removed and the corresponding weights will be merged.
##' @param weight Numeric vector of weights that appear in the composite check
##'   loss. Each element must be between 0 and 1. The vector should be
##'   normalized in the sense that the sum of the weights is unitary. The length
##'   of the vector must be the same as that of \code{tau}.
##' @param nlambda The number of \code{lambda} values (default is \code{100L}).
##' @param method A character string specifying the algorithm to use. Only
##'   "\code{admm}" is available now.
##' @param lambda_factor The factor for getting the minimal value in the
##'   \code{lambda} sequence, where \code{lambda_factor=max(lambda)/min(lambda)}
##'   and \code{max(lambda)} is the smallest value of \code{lambda} for which
##'   all the coefficients (except the intercepts) are penalized to zero. The
##'   default depends on the relationship between \eqn{n} (the number of rows in
##'   the design matrix) and \eqn{p} (the number of predictors). If \eqn{n < p},
##'   it defaults to \code{0.05}. If \eqn{n > p}, the default is \code{0.0005},
##'   closer to zero. A very small value of \code{lambda_factor} will lead to a
##'   saturated fit. The argument takes no effect if there is a user-supplied
##'   \code{lambda} sequence.
##' @param lambda A user-supplied \code{lambda} sequence. Typically, by leaving
##'   this option unspecified, users can have the program compute its own
##'   \code{lambda} sequence based on \code{nlambda} and \code{lambda_factor}.
##'   It is recommended to supply, if necessary, a decreasing sequence of
##'   \code{lambda} values than a single (small) value. The program will ensure
##'   that the user-supplied \code{lambda} sequence is sorted in decreasing
##'   order before fitting the model.
##' @param lambda2 Regularization parameter \code{lambda2} for the L2 penalty of
##'   the coefficients. Unlike \code{lambda}, only one value of \code{lambda2}
##'   is used for each fitting process.
##' @param pf L1 penalty factor of length \eqn{p} used for the weighted lasso or
##'   weighted elastic net. Separate L1 penalty weights can be applied to each
##'   coefficient to allow different L1 shrinkage. Can be 0 for some variables,
##'   which imposes no shrinkage, and results in that variable always being
##'   included in the model. Default is 1 for all variables.
##' @param pf2 L2 penalty factor of length \eqn{p} used for weighted elastic
##'   net. Separate L2 penalty weights can be applied to each coefficient to
##'   allow different L2 shrinkage. Can be 0 for some variables, which imposes
##'   no shrinkage. Default is 1 for all variables.
##' @param dfmax The maximum number of variables allowed in the model. Useful
##'   for very large \eqn{p} when a partial solution path is desired. Default is
##'   \eqn{p+1}.
##' @param vmax The maximum number of coefficients allowed ever to be nonzero
##'   along the solution path. Once a \eqn{\beta} component enters the model, no
##'   matter how many times it exits or re-enters the model through the path, it
##'   will be counted only once. Default is \code{min(dfmax * 1.2, p)}.
##' @param standardize Logical flag for variable standardization, prior to
##'   fitting the model sequence. The coefficients are always returned to the
##'   original scale. Default is \code{TRUE}.
##' @param eps Convergence thresholds for the ADMM algorithm. A numeric vector
##'   of length 2. The first component is the absolute tolerance and the second
##'   component is the relative tolerance. The two together control the primal
##'   and dual residuals of the ADMM algorithm. Default value is \code{c(1e-3,
##'   1e-3)}.
##' @param maxit Maximum number of iterations allowed in the ADMM algorithm at
##'   fixed lambda values. Default is \code{100000L}.
##' @param sigma Penalty parameter appearing in the quadratic term of the
##'   augmented Lagrangian function. Must be positive.
##' @param lambda_only Logical flag indicating whether or not to only compute
##'   the lambda sequence. If \code{TRUE}, the coefficients \code{beta} and
##'   \code{alpha} will not be computed and only the \code{lambda} sequence is
##'   effectively calculated. Otherwise, the coefficients as well as the
##'   \code{lambda} sequence will be computed. Default is \code{FALSE}.
##'
##' @export
##'
##' @details The objective function in the penalized composite quantile
##'   regression is of the form "composite check loss plus penalty," where
##'   the composite loss is a weighted sum of quantile check loss functions,
##'   and the penalty is composed of weighted L1 and L2 terms.
##'
##'   For faster computation, if the algorithm is not converging or running
##'   slow, consider increasing \code{eps}, decreasing \code{nlambda}, or
##'   increasing \code{lambda_factor} before increasing \code{maxit}.
##'
##' @return \code{cqrwenet} returns an object of \code{\link{class}}
##'   \code{"cqrwenet"} and \code{"cqrwenetpath"}.
##'
##' An object of S3 class \code{"cqrwenet"} is a list consisting of
##'
##'  \item{call}{the call that produced this object.}
##'
##'  \item{alpha}{matrix of intercepts, of dimension
##'               \code{length(tau)}*\code{length(lambda)}.}
##'
##'  \item{beta}{a \code{p*length(lambda)} matrix of coefficients,
##'              stored as a sparse matrix (\code{dgCMatrix} class,
##'              the standard class for sparse numeric matrices in
##'              the \code{Matrix} package.). To convert it into
##'              normal type matrix, use \code{as.matrix()}.}
##'
##'  \item{lambda}{the actual sequence of \code{lambda} values used.}
##'
##'  \item{df}{the number of nonzero coefficients for each value
##'            of \code{lambda}.}
##'
##'  \item{dim}{dimension of coefficient matrix.}
##'
##'  \item{npasses}{total number of iterations summed over all lambda values.}
##'
##'  \item{jerr}{error flag, for warnings and errors, 0 if no error.}
##'
##'  \item{sigma}{actually used penalty parameter in the ADMM algorithm.}
##'
##' @author
##' Yuwen Gu <yuwen.gu@uconn.edu>
##'
##' Maintainer: Yuwen Gu <yuwen.gu@uconn.edu>
##'
##' @references
##' Zou, Hui and Yuan, Ming, "Composite quantile regression and the oracle
##'      model selection theory,"
##'   \emph{The Annals of Statistics}, 36(3), 1108–1126 (2008).
##'   http://dx.doi.org/10.1214/07-aos507
##'
##' Gu, Yuwen and Zou, Hui, "Sparse composite quantile regression in ultrahigh
##'     dimensions with tuning parameter calibration,"
##'   \emph{IEEE Transactions on Information Theory}, 66(11), 7132–7154 (2020).
##'   http://dx.doi.org/10.1109/tit.2020.3001090.
##'
##' @seealso
##' \code{print}, \code{coef}, \code{predict}, and \code{plot} methods, and
##' the \code{\link{cv.cqrwenet}} function
##'
##' @examples
##' set.seed(1)
##' n <- 100
##' p <- 400
##' x <- matrix(rnorm(n * p), n, p)
##' y <- rnorm(n)
##' tau <- seq(1, 19)/20
##' weight <- rep(1/length(tau), length(tau))
##' pf <- abs(rnorm(p))
##' pf2 <- abs(rnorm(p))
##' lambda2 <- 1.0
##' m <- cqrwenet(x = x, y = y, tau = tau, weight = weight,
##'               pf = pf, pf2 = pf2, standardize = FALSE,
##'               lambda2 = lambda2, sigma = rep(1.0, 100))
##'
##' @keywords models regression

##' @useDynLib FHDCQR, .registration = TRUE
##' @importFrom Rcpp evalCpp
cqrwenet <- function(x, y, tau, weight, nlambda = 100L, method = "admm",
                     lambda_factor = ifelse(nobsn < nvars, 0.05, 0.0005),
                     lambda = NULL, lambda2 = 0, pf = rep(1.0, nvars),
                     pf2 = rep(1.0, nvars), dfmax = nvars + 1,
                     vmax = min(dfmax * 1.2, nvars), standardize = TRUE,
                     lambda_only = FALSE, eps = c(1e-03, 1e-03),
                     maxit = 100000L, sigma = NULL) {
  ##----------------------------------------------------------------------------
  ## DATA SETUP
  method <- match.arg(method)
  this_call <- match.call()
  y <- drop(y)
  x <- as.matrix(x)
  np <- dim(x)
  nobsn <- as.integer(np[1L])
  nvars <- as.integer(np[2L])
  if (nobsn <= 1L)
    stop("too few observations!")
  if (nvars <= 0L)
    stop("no predictors! use `stats::quantile()` function")
  vnames <- colnames(x)
  if (is.null(vnames)) vnames <- paste0("v", seq(nvars))
  if (NROW(y) != nobsn)
    stop("x & y have different number of observations")
  if (NCOL(y) > 1L)
    stop("multivariate response is not yet supported")
  ##----------------------------------------------------------------------------
  ## PARAMETER SETUP
  tau <- as.numeric(tau)
  weight <- as.numeric(weight)
  ntaus <- length(tau)
  if (ntaus < 1L)
    stop("a sequence of quantile levels must be supplied")
  if (ntaus > 100L)
    stop("too many quantile levels ==> computation will be slow")
  if (length(weight) != ntaus)
    stop("quantile levels and weights have different lengths")
  dups <- duplicated(tau)
  if (any(dups)) {
    warning(paste0("duplicated quantile levels found!\n",
                   "...removing duplicates and merging weights..."))
    dup_ids <- which(dups)
    for (i in seq_along(dup_ids)) {
      which_dup <- which(tau[dup_ids[i]] == tau[seq(dup_ids[i] - 1L)])
      weight[which_dup] <- weight[which_dup] + weight[dup_ids[i]]
    }
    tau <- tau[!dups]
    weight <- weight[!dups]
  }
  ntaus <- length(tau)
  if (any(tau <= 0.0 || tau >= 1.0))
    stop("quantile levels must be strictly between 0 and 1")
  if (any(weight < 0.0 || weight > 1.0))
    stop("weights must be between 0.0 and 1.0")
  if (sum(weight) <= 0.0)
    stop("all weights are zero; assign postive weights")
  if (abs(sum(weight) - 1.0) > 1.0e-6) {
    warning(paste0("weights are not normalized; double check them.\n",
                   "...now normalizing the weights..."))
  }
  weight <- weight / sum(weight)
  if (length(pf) != nvars)
    stop(paste("size of L1 penalty factors does not match",
               "the number of input variables"))
  pf <- as.double(pf)
  if (length(pf2) != nvars)
    stop(paste("size of L2 penalty factors does not match",
               "the number of input variables"))
  pf2 <- as.double(pf2)
  if (lambda2 < 0.0)
    stop("`lambda2` must be non-negative")
  lam2 <- as.double(lambda2)
  maxit <- as.integer(maxit)
  isd <- as.integer(standardize)
  eps <- as.double(eps)
  if (length(eps) != 2L)
    stop("two tolerances (absolute & relative) must be supplied")
  dfmax <- as.integer(dfmax)
  vmax <- as.integer(vmax)
  ##----------------------------------------------------------------------------
  ## LAMBDA AND SIGMA SETUP
  nlam <- as.integer(nlambda)
  if (is.null(lambda)) {
    if (lambda_factor >= 1.0 | lambda_factor <= 0.0)
      stop("`lambda_factor` must be between 0 and 1")
    flmin <- as.double(lambda_factor)
    ulam <- double(nlam)
  } else {
    flmin <- as.double(1.0) # flmin = 1 if user defines lambda
    if (any(lambda < 0.0))
      stop("`lambda`s should be non-negative")
    ulam <- as.double(rev(sort(lambda)))
    nlam <- as.integer(length(lambda))
  }
  if (is.null(sigma)) {
    stop("`sigma` must be supplied")
  }
  else {
    sigma <- as.numeric(sigma)
    if (any(sigma <= 0.0))
      stop("`sigma` must be positive")
    if (length(sigma) == 1L) sigma <- rep(sigma, nlam)
    if (length(sigma) != nlam)
      stop("`sigma` and `lambda`: length mismatch")
  }
  onlylam <- as.logical(lambda_only)
  ##----------------------------------------------------------------------------
  ## TYPE CONVERSION
  storage.mode(y) <- "double"
  storage.mode(x) <- "double"
  tau <- as.double(tau)
  weight <- as.double(weight)
  sigma <- as.double(sigma)
  ## CALL CPP CORE
  fitter <- switch(method,
                   admm = .Call(`_FHDCQR_CQRWENET`, x, y, tau, weight,
                                pf, pf2, nlam, flmin, ulam, lam2, isd,
                                vmax, dfmax, eps, maxit, sigma,
                                onlylam, PACKAGE = "FHDCQR"))
  fit <- getoutput(fitter, maxit, vmax, nvars, ntaus, vnames, onlylam)
  fit <- c(fit, list(npasses = as.integer(fitter$npass),
                     jerr = as.integer(fitter$jerr)))
  if (is.null(lambda) && !onlylam)
    fit$lambda <- lamfix(fit$lambda)
  fit$call <- this_call
  class(fit) <- c("cqrwenet", "cqrwenetpath")
  fit
}
