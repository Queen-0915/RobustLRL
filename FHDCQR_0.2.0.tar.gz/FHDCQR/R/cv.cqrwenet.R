#' Cross-validation for the adaptive elastic net penalized composite quantile
#' regression
#'
#' Does k-fold cross-validation for the adaptive lasso and elastic-net penalized
#' composite quantile regression, produces a plot, and returns cross-validated
#' results for best `lambda`.
#'
#' @param x The \code{x} matrix as in \code{\link{cqrwenet}}.
#' @param y Response variable \code{y} as in \code{\link{cqrwenet}}.
#' @param tau Vector of quantile levels used in the composite check loss.
#' @param weight Vector of weights corresponding to the quantile levels in the
#'   composite check loss.
#' @param lambda Optional user-supplied lambda sequence; default is \code{NULL},
#'   for which \code{\link{cqrwenet}} chooses its own sequence.
#' @param pred.loss Loss function used to calculate the cross-validation error.
#'   The only option now is "\code{loss}", which is the composite check loss.
#' @param nfolds Number of folds. Default value is \code{5L}. Although
#'   \code{nfolds} can be as large as the sample size (the leave-one-out CV), it
#'   is not recommended for large data sets. Smallest value allowed is
#'   \code{3L}.
#' @param foldid An optional vector of values between 1 and \code{nfolds},
#'   identifying which fold each observation is in. If supplied, \code{nfolds}
#'   will be supressed.
#' @param parallel Logical indicator of whether or not using parallelization to
#'   do \code{nfolds} cross-validation. Default is \code{TRUE}. Recommended for
#'   large data sets.
#' @param mc.cores The number of cores to use, i.e. at most how many child
#'   processes will be run simultaneously. The option is initialized from
#'   environment variable \code{MC_CORES} if set. Must be at least one, and
#'   parallelization requires at least two cores. Not effective if
#'   \code{parallel} is set to \code{FALSE}.
#' @param \dots Other arguments that can be passed to \code{cqrwenet}.
#'
#' @export
#'
#' @details The function runs \code{\link{cqrwenet}} (\code{nfolds}+1) times;
#'   the first is fitted to get the \code{lambda} sequence, and the remainder
#'   are used to compute the fit with each of the folds removed. The average
#'   error and standard deviation over the folds are computed.
#'
#' @return
#' An object of class \code{cv.cqrwenet} is returned,
#' which is a list with the ingredients of the cross-validated fit.
#'  \item{lambda}{the values of \code{lambda} used in the fits}
#'  \item{cvm}{the mean cross-validated error - a vector of length
#'             \code{length(lambda)}}
#'  \item{cvsd}{estimate of standard error of \code{cvm}}
#'  \item{cvupper}{upper curve = \code{cvm+cvsd}}
#'  \item{cvlower}{lower curve = \code{cvm-cvsd}}
#'  \item{nzero}{number of non-zero coefficients at each \code{lambda}}
#'  \item{name}{a text string indicating type of measure
#'              (for plotting purposes)}
#'  \item{cqrwenet.fit}{a fitted \code{\link{cqrwenet}} object for
#'                      the full data}
#'  \item{lambda.min}{The optimal value of \code{lambda} that
#'                    gives minimum cross validation error \code{cvm}}
#'  \item{lambda.1se}{The largest value of \code{lambda} such that
#'                    error is within 1 standard error of the minimum}
#'
#' @author
#' Yuwen Gu <yuwen.gu@uconn.edu>,
#' Hui Zou <zouxx019@umn.edu>
#'
#' Maintainer: Yuwen Gu <yuwen.gu@uconn.edu>
#'
#' @seealso \code{\link{cqrwenet}}
#'
#' @examples
#' set.seed(1)
#' n <- 100
#' p <- 200
#' x <- matrix(rnorm(n*p), n, p)
#' y <- rnorm(n)
#' tau <- seq(1, 19)/20
#' weight <- rep(1/length(tau), length(tau))
#' lambda2 <- 1.0
#' cvmodels <- cv.cqrwenet(x = x, y = y, tau = tau,
#'                         weight = weight,
#'                         standardize = FALSE,
#'                         lambda2 = lambda2,
#'                         sigma = rep(1.0, 100))
#'
#' @keywords models regression
#'
#' @importFrom parallel mclapply
cv.cqrwenet <- function(x, y, tau, weight, lambda = NULL,
                        pred.loss = "loss", nfolds = 5L,
                        foldid, parallel = TRUE,
                        mc.cores = getOption("mc.cores", 2L),
                        ...) {
  pred.loss <- match.arg(pred.loss)
  N <- nrow(x)
  ## FIT THE MODEL ONCE TO GET MODEL PARAMETERS
  y <- drop(y)
  cqrwenet.object <- cqrwenet(x, y, tau = tau, weight = weight,
                              lambda = lambda, ...)
  lambda <- cqrwenet.object$lambda
  ## PREDICTTIONS =====> COEFFICIENTS
  nz <- sapply(coef(cqrwenet.object, type = "nonzero"), length)
  if (missing(foldid)) {
    foldid <- sample(rep(seq(nfolds), length = N))
  } else nfolds <- max(foldid)
  if (nfolds < 3L)
    stop("nfolds must be at least 3; nfolds = 5 recommended")
  ## NOW FIT THE NFOLD MODELS AND STORE THEM
  fit_models <- function(index) {
    whichfold <- foldid == index
    y_sub <- y[!whichfold]
    cqrwenet(x = x[!whichfold, , drop = FALSE],
             y = y_sub, tau = tau, weight = weight,
             lambda = lambda, ...)
  }
  if (parallel) {
    outlist <- mclapply(seq(nfolds), fit_models,
                        mc.cores = mc.cores)
  } else {
    outlist <- lapply(seq(nfolds), fit_models)
  }
  ## WHAT TO DO DEPENDS ON THE PRED.LOSS AND THE MODEL FIT
  fun <- paste("cv", class(cqrwenet.object)[[2]], sep = ".")
  cvstuff <- do.call(fun, list(outlist, lambda, x, y,
                               foldid, pred.loss, tau,
                               weight))
  cvm <- cvstuff$cvm
  cvsd <- cvstuff$cvsd
  cvname <- cvstuff$name
  out <- list(lambda = lambda, cvm = cvm, cvsd = cvsd,
              cvupper = cvm + cvsd, cvlower = cvm - cvsd,
              nzero = nz, name = cvname,
              cqrwenet.fit = cqrwenet.object)
  lamin <- getmin(lambda, cvm, cvsd)
  obj <- c(out, as.list(lamin))
  class(obj) <- "cv.cqrwenet"
  obj
}


##==============================================================================

cv.cqrwenetpath <- function(outlist, lambda, x, y, foldid, pred.loss, tau,
                            weight) {
  typenames <- "Composite check loss"
  if (!match(pred.loss, c("loss"), FALSE)) {
    warning("Only `loss` is available for CQR")
    pred.loss <- "loss"
  }
  y <- as.double(y)
  nfolds <- max(foldid)
  predmat <- array(NA, dim = c(length(y), length(tau), length(lambda)))
  nlams <- double(nfolds)
  for (i in seq(nfolds)) {
    whichfold <- foldid == i
    fitobj <- outlist[[i]]
    preds <- predict(fitobj, x[whichfold, , drop = FALSE], type = "response")
    nlami <- length(outlist[[i]]$lambda)
    predmat[whichfold, , seq(nlami)] <- preds
    nlams[i] <- nlami
  }
  cvraw <- apply(y - predmat, c(1, 3), compo_check, tau, weight)
  N <- length(y) - apply(is.na(cvraw), 2, sum)
  cvm <- apply(cvraw, 2, mean, na.rm = TRUE)
  cvsd <- sqrt(apply(scale(cvraw, cvm, FALSE) ^ 2,
                     2, mean, na.rm = TRUE) / (N - 1))
  list(cvm = cvm, cvsd = cvsd, name = typenames)
}
