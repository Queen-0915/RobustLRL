
#include "RcppArmadillo.h"
// using namespace arma;

const arma::uword MNLAM = 5;
const double BIG = std::numeric_limits<double>::max();
const double SMALL = std::numeric_limits<double>::epsilon();
const double MFL = 1.0e-6;

// [[Rcpp::depends(RcppArmadillo)]]

//-[[Rcpp::export]]
Rcpp::List CQRWENET(SEXP x_, SEXP y_, SEXP taus_, SEXP weights_,
                    SEXP pf_, SEXP pf2_, SEXP nlam_, SEXP flmin_,
                    SEXP ulam_, SEXP lam2_, SEXP isd_, SEXP pmax_,
                    SEXP dfmax_, SEXP eps_, SEXP maxit_,
                    SEXP sigma_, SEXP onlylam_) {
  /* ---------- INPUT VARIABLES ---------- */
  arma::mat         x = Rcpp::as<arma::mat>(x_);
  arma::vec         y = Rcpp::as<arma::vec>(y_);
  arma::vec      taus = Rcpp::as<arma::vec>(taus_);
  arma::vec   weights = Rcpp::as<arma::vec>(weights_);
  arma::vec        pf = Rcpp::as<arma::vec>(pf_);
  arma::vec       pf2 = Rcpp::as<arma::vec>(pf2_);
  arma::uword    nlam = Rcpp::as<arma::uword>(nlam_);
  double        flmin = Rcpp::as<double>(flmin_);
  arma::vec      ulam = Rcpp::as<arma::vec>(ulam_);
  double         lam2 = Rcpp::as<double>(lam2_);
  arma::uword     isd = Rcpp::as<arma::uword>(isd_);
  arma::uword    pmax = Rcpp::as<arma::uword>(pmax_);
  arma::uword   dfmax = Rcpp::as<arma::uword>(dfmax_);
  arma::vec       eps = Rcpp::as<arma::vec>(eps_);
  arma::uword   maxit = Rcpp::as<arma::uword>(maxit_);
  arma::vec     sigma = Rcpp::as<arma::vec>(sigma_);
  arma::uword onlylam = Rcpp::as<arma::uword>(onlylam_);

  /* ---------- SANITY CHECK ---------- */
  arma::uword nobs  = x.n_rows;
  arma::uword nvars = x.n_cols;
  arma::uword ntaus = taus.n_elem;
  arma::vec xmean(nvars, arma::fill::zeros);
  arma::vec xnorm(nvars, arma::fill::zeros);
  bool ju = false;
  double z = 0.0;
  for (arma::uword j = 0; j < nvars; j++) {
    ju = false;
    z = x(0, j);
    for (arma::uword i = 1; i < nobs; i++) {
      if (x(i, j) != z) {
        ju = true;
        break;
      }
    }
    if (!ju) Rcpp::stop("Some variable in x has zero variance");
  }
  if (pf.max() <= 0.0) Rcpp::stop("All L1 penalty factors are zero");
  pf = (pf + arma::abs(pf)) * 0.5;
  if (pf2.max() <= 0.0) Rcpp::stop("All L2 penalty factors are zero");
  pf2 = (pf2 + arma::abs(pf2)) * 0.5;

  /* ---------- STANDARDIZE PREDICTOR VARIABLES ---------- */
  for (arma::uword j = 0; j < nvars; j++) {
    xmean(j) = arma::mean(x.col(j)); // MEAN
    x.col(j) -= xmean(j); // ALWAYS CENTER
    if (isd == 1) {
      z = arma::dot(x.col(j), x.col(j)) / nobs;
      xnorm(j) = ::sqrt(z);
      x.col(j) /= xnorm(j);
    }
  }

  /* ---------- CALCULATE INVERSE MATRIX ---------- */
  arma::mat invmat(nvars, nvars, arma::fill::zeros);
  arma::uword npmin = (nobs > nvars) ? nvars : nobs;
  arma::mat wbmat(npmin, npmin, arma::fill::zeros);
  if (nobs > nvars) {
    wbmat = x.t() * x * ntaus;
  } else {
    wbmat = x * x.t() * ntaus;
  }
  wbmat.diag() += 1.0;
  if (nobs > nvars) {
    invmat = arma::inv_sympd(wbmat);
  } else {
    invmat = x.t() * arma::inv_sympd(wbmat) * x * (-1.0) * ntaus;
    invmat.diag() += 1.0;
  }

  /* ---------- INITIALIZATION OF ADMM ---------- */
  arma::mat U(nobs, ntaus, arma::fill::zeros);
  arma::vec v(nvars, arma::fill::zeros);
  arma::rowvec a(ntaus, arma::fill::zeros);
  arma::vec b(nvars, arma::fill::zeros);
  arma::vec g(nvars, arma::fill::zeros), g0 = g;
  arma::mat Y = arma::repmat(y, 1, ntaus), r = Y, Z = Y, Z0 = Y;
  arma::mat tt(nobs, ntaus, arma::fill::zeros);
  arma::uvec mm(nvars, arma::fill::zeros);
  arma::uword cntr = 0, ni = 0, count = 0;
  arma::uword mnl = (nlam > MNLAM) ? MNLAM : nlam;
  // VARIABLES TO RETURN
  int jerr = 0;
  arma::mat alpha(nlam, ntaus, arma::fill::zeros);
  arma::mat beta(pmax, nlam, arma::fill::zeros);
  // arma::cube res(nobs, ntaus, nlam, arma::fill::zeros);
  arma::vec alam(nlam, arma::fill::zeros);
  arma::uvec ibeta(pmax, arma::fill::zeros), Ibeta = ibeta;
  arma::uvec nbeta(nlam, arma::fill::zeros);
  arma::uword npass = 0, nalam = 0;

  double alf = 0.0, yn = ::sqrt(arma::dot(y, y) * ntaus);
  if (flmin < 1.0) {
    flmin = std::max(MFL, flmin);
    alf = ::pow(flmin, 1.0 / (nlam - 1));
  }

  /* ---------- LAMBDA LOOP ---------- */
  bool conv = true;
  double al = 0.0, s = 0.0, t = 0.0;
  for (arma::uword l = 0; l < nlam; l++) {
    if (flmin >= 1.0) al = ulam(l);
    else if (l > 1) al *= alf;
    else if (l == 0) al = BIG;
    else if (l == 1) {
      // COMPUTE LAMBDA_MAX
      al = 0.0;
      for (arma::uword j = 0; j < nvars; j++) {
        if (pf(j) > 0.0) {
          al = std::max((std::abs(arma::dot(taus - 0.5, weights) *
                                  arma::accu(x.col(j)) + 0.5 *
                                  arma::dot(x.col(j),
                                            arma::sign(r) * weights)) +
                         arma::dot((1.0 - arma::abs(arma::sign(r))) *
                                   weights * 0.5, arma::abs(x.col(j)))) / pf(j),
                        al);
        }
      }
      if (onlylam == 1) {
        alam(0) = al / nobs;
        for (arma::uword k = 1; k < nlam; k++) {
          alam(k) = alam(k - 1) * alf;
        }
        nalam = nlam;
        break;
      }
      al *= alf / nobs;
    }

    /* ---------- ADMM LOOP ---------- */
    cntr = 0; // COUNTER FOR EACH LAMBDA
    do {
      npass++; // COUNTER OVER ALL LAMBDA
      /* ---------- UPDATE ALPHA & BETA ---------- */
      tt = sigma(l) * (Y - Z) - U;
      a = arma::sum(tt, 0) / (nobs * sigma(l));
      b = invmat * (x.t() * arma::sum(tt, 1) + sigma(l) * g + v) / sigma(l);
      /* ---------- UPDATE Z & GAMMA ---------- */
      Z0 = Z;
      r = Y - arma::repmat(a, nobs, 1) - arma::repmat(x * b, 1, ntaus);
      Z = r - U / sigma(l);
      Z -= arma::max(arma::repmat(((taus - 1.0) % weights).t() /
                                  (nobs * sigma(l)), nobs, 1),
                     arma::min(Z, arma::repmat((taus % weights).t() /
                                               (nobs * sigma(l)), nobs, 1)));
      g0 = g;
      for (arma::uword j = 0; j < nvars; j++) {
        s = sigma(l) * b(j) - v(j);
        t = std::abs(s) - al * pf(j);
        if (t > 0.0) {
          g(j) = arma::sign(s) * t / (sigma(l) + pf2(j) * lam2);
        } else {
          g(j) = 0.0;
        }
        z = g(j) - g0(j);
        if (std::abs(z) > 0.0) {
          if (mm(j) == 0) {
            ni++;
            if (ni > pmax) break;
            mm(j) = ni;
            ibeta(ni - 1) = j;
            Ibeta(ni - 1) = j + 1; // RECORD ACTIVE VARIABLES
          }
        }
      }
      if (ni > pmax) break;
      /* ---------- UPDATE U & V ---------- */
      U += sigma(l) * (Z - r);
      v += sigma(l) * (g - b);

      /* ---------- CONVERGENCE CHECK ---------- */
      cntr++;
      // IMPLEMENT CONVERGENCE CRITERION
      conv = true;
      s = ::sqrt(arma::dot(Z - r, Z - r) + arma::dot(g - b, g - b));
      tt = Z - Z0;
      t = ::sqrt(arma::accu(arma::square(arma::sum(tt, 0))) +
                 arma::accu(arma::square(x.t() * arma::sum(tt, 1) +
                                         g0 - g))) * sigma(l);
      if (s > ::sqrt(nobs * ntaus + nvars) * eps(0) + eps(1) *
          std::max(std::max(yn, ::sqrt(arma::dot(Z, Z) + arma::dot(g, g))),
                   ::sqrt(arma::dot(Y - r, Y - r) + arma::dot(b, b))))
        conv = false;
      if (t > ::sqrt(nvars + ntaus) * eps(0) + eps(1) *
          ::sqrt(arma::accu(arma::square(arma::sum(U, 0))) +
                 arma::accu(arma::square(x.t() * arma::sum(U, 1) - v))))
        conv = false;
      if (conv) break;
    } while (cntr < maxit);
    /* ----------- FINAL UPDATE & SAVE RESULTS ------------ */
    if (cntr >= maxit) {
      jerr = -(l + 1);
      // Rcpp::warning("ADMM not converged");
      break;
    }
    if (ni > pmax) {
      jerr = -777778 - l;
      break;
    }
    // SAVE RESULTS: USE MAT & ARRAY
    alpha.row(l) = a;
    if (ni > 0) {
      beta.col(l).head(ni) = g.elem(ibeta.head(ni));
    }
    nbeta(l) = ni;
    // res.slice(l) = r;
    alam(l) = al;
    nalam = l + 1;
    if (l < mnl) continue;
    if (flmin >= 1.0) continue;
    if (dfmax < nvars) {
      count = arma::accu(arma::abs(beta.col(l).head(ni)) > SMALL);
      if (count > dfmax) break;
    }
  }
  // RETURN RESULTS: TRANSFORM BACK IF NECESSARY
  for (arma::uword l = 0; l < nalam; l++) {
    ni = nbeta(l);
    if (ni > 0) {
      if (isd == 1) {
        for (arma::uword j = 0; j < ni; j++) {
          beta(j, l) /= xnorm(ibeta(j));
        }
      }
      alpha.row(l) -= arma::dot(xmean.elem(ibeta.head(ni)),
                                beta.col(l).head(ni));
    }
  }
  return Rcpp::List::create(Rcpp::Named("beta") = beta,
                            Rcpp::Named("alpha") = alpha.t(),
                            // Rcpp::Named("residuals") = res,
                            Rcpp::Named("alam") = alam,
                            Rcpp::Named("nlam") = nlam,
                            Rcpp::Named("nalam") = nalam,
                            Rcpp::Named("nbeta") = nbeta,
                            Rcpp::Named("ibeta") = Ibeta,
                            Rcpp::Named("npass") = npass,
                            Rcpp::Named("jerr") = jerr);
}
