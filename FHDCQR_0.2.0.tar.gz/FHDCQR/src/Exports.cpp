
#include <RcppArmadillo.h>
#include <Rcpp.h>

using namespace Rcpp;

#ifdef RCPP_USE_GLOBAL_ROSTREAM
Rcpp::Rostream<true>&  Rcpp::Rcout = Rcpp::Rcpp_cout_get();
Rcpp::Rostream<false>& Rcpp::Rcerr = Rcpp::Rcpp_cerr_get();
#endif

// CQRWENET
Rcpp::List CQRWENET(SEXP x_, SEXP y_, SEXP taus_, SEXP weights_, SEXP pf_, SEXP pf2_, SEXP nlam_, SEXP flmin_, SEXP ulam_, SEXP lam2_, SEXP isd_, SEXP pmax_, SEXP dfmax_, SEXP eps_, SEXP maxit_, SEXP sigma_, SEXP onlylam_);
RcppExport SEXP _FHDCQR_CQRWENET(SEXP x_SEXP, SEXP y_SEXP, SEXP taus_SEXP, SEXP weights_SEXP, SEXP pf_SEXP, SEXP pf2_SEXP, SEXP nlam_SEXP, SEXP flmin_SEXP, SEXP ulam_SEXP, SEXP lam2_SEXP, SEXP isd_SEXP, SEXP pmax_SEXP, SEXP dfmax_SEXP, SEXP eps_SEXP, SEXP maxit_SEXP, SEXP sigma_SEXP, SEXP onlylam_SEXP) {
BEGIN_RCPP
    Rcpp::RObject rcpp_result_gen;
    Rcpp::RNGScope rcpp_rngScope_gen;
    Rcpp::traits::input_parameter< SEXP >::type x_(x_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type y_(y_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type taus_(taus_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type weights_(weights_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type pf_(pf_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type pf2_(pf2_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type nlam_(nlam_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type flmin_(flmin_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type ulam_(ulam_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type lam2_(lam2_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type isd_(isd_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type pmax_(pmax_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type dfmax_(dfmax_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type eps_(eps_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type maxit_(maxit_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type sigma_(sigma_SEXP);
    Rcpp::traits::input_parameter< SEXP >::type onlylam_(onlylam_SEXP);
    rcpp_result_gen = Rcpp::wrap(CQRWENET(x_, y_, taus_, weights_, pf_, pf2_, nlam_, flmin_, ulam_, lam2_, isd_, pmax_, dfmax_, eps_, maxit_, sigma_, onlylam_));
    return rcpp_result_gen;
END_RCPP
}

static const R_CallMethodDef CallEntries[] = {
    {"_FHDCQR_CQRWENET", (DL_FUNC) &_FHDCQR_CQRWENET, 17},
    {NULL, NULL, 0}
};

RcppExport void R_init_FHDCQR(DllInfo *dll) {
    R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
