
tic()
out_deSubGD <- deSubGD(X, 
                       y,
                       adjacency_matrix,
                       B_init,
                       betaT,
                       T = T,
                       K = K,
                       lambda_max = 20,
                       quiet = quiet)
toc()

tic()
out_SubGD <- SubGD(X, 
                   y,
                   B_init[,1],
                   betaT,
                   T = T,
                   K = K,
                   lambda_max = 20,
                   nlambda = 2,
                   quiet = quiet)
toc()
beta_pooled <- out_SubGD$b
coef.cutoff <- 1e-1
beta_pooled[abs(beta_pooled) <= coef.cutoff] <- 0
norm(out_SubGD$b - betaT, type = "F")
esupp <- which(abs(beta_pooled)>0)
computeF1(esupp, suppT)


# local
tic()
out_SubGD <- SubGD(X[1:n,], 
                   y[1:n,],
                   B_init[,1],
                   betaT,
                   T = T,
                   K = K,
                   lambda_max = 20,
                   nlambda = 100,
                   quiet = quiet)
toc()
beta_local <- out_SubGD$b
coef.cutoff <- 1e-1
beta_local[abs(beta_local) <= coef.cutoff] <- 0
norm(out_SubGD$b - betaT, type = "F")
esupp <- which(abs(beta_local)>0)
computeF1(esupp, suppT)


## hereg
cv_raw = cv.hqreg(X[1:N,], y[1:N], FUN = "hqreg_raw", seed = 321, method = "quantile", tau = mean(tau_K))
ii <- which(cv_raw$lambda == cv_raw$lambda.min)
beta <- cv_raw$fit$beta[2:(p + 1),ii]
norm(beta - betaT, type = "F")
coef.cutoff <- 1e-1
beta[abs(beta) <= coef.cutoff] <- 0
esupp <- which(abs(beta)>0)
computeF1(esupp, suppT)

sqrt(norm(out_beta_deSCQR$B - pracma::repmat(betaT, 1, m), type = "F")^2/m)
# pooled
# tic()
# weight <- rep(1/length(tau_K), length(tau_K))
# cvmodels <- cv.cqrwenet(
#   y = y,
#   x = X,
#   tau = tau_K,
#   weight = weight,
#   lambda2 = 0,
#   nlambda = nlambda,
#   eps = c(1e-2, 1e-2),
#   sigma = rep(1.0, nlambda)
# )
# toc()
# 
# ii <- which(cvmodels$lambda == cvmodels$lambda.min)
# out <- matrix(cvmodels$cqraenet.fit$beta[, ii])
# # coef.cutoff <- 1e-1
# # out[abs(out) <= coef.cutoff] <- 0
# coef.cutoff <- 5e-1
# out[abs(out) <= coef.cutoff] <- 0
# B_init[, j] <- out
# A_init[, j] <-
#   matrix(quantile(y[idx] - X[idx,] %*% B_init[, j], tau_K))

b <- t(X)%*%y/N
linf <- norm(b, "I")
Lmax <- 1
Lmin <- lambda_factor
Lam <- exp(seq(log(Lmax), log(Lmin), length.out = nlambda))
Lam <- Lam[2:length(Lam)]
Lam <- Lam * linf
bic_array <- rep(NA, nlambda - 1)
tic()
for(ilambda in seq_along(Lam)) {
  lambda <- Lam[ilambda]
  out <- cqr.fit.lasso(X, y, tau_K, lambda = lambda, method = "mm")
  # coef.cutoff <- 5e-1
  # out$beta[abs(out$beta) <= coef.cutoff] <- 0
  # bic_array[ilambda] <-  mean((y - X%*%out$beta)^2) + log(N)*log(log(N))/N*sum(abs(out$beta)>0)
  bic_array[ilambda] <-  cqr_loss_cpp(X, y, out$beta, matrix(out$b), tau_K)/ K/ N + log(N)*log(log(N))/N*sum(abs(out$beta)>0)
}
toc()
ii <- which.min(bic_array)
lambda <- Lam[ii]
out <- cqr.fit.lasso(X, y, tau_K, lambda = lambda, method = "mm")
beta <- out$beta
coef.cutoff <- 5e-1
beta[abs(beta) <= coef.cutoff] <- 0
esupp <- which(abs(beta)>0)
computeF1(esupp, suppT)
# sqrt(sum((out$beta - betaT)^2))
# 

# my
fit_pooledCQR <- cqr_dist(X, y, 1, s, A_init[,1], B_init[,1], tau_K, c = 1, MAXIT_DIST = 20, tol = -Inf)
beta <- fit_pooledCQR$beta
sqrt(sum((fit_pooledCQR$beta - betaT)^2))
errs_pooled <- apply(fit_pooledCQR$history$beta, 2, function(x)
  norm(matrix(x - betaT), "F"))
plot(errs_pooled)


# local
fit_localCQR <- cqr_dist(X[1:n,], y[1:n], 1, s, A_init[,1], B_init[,1], tau_K, c = 1, MAXIT_DIST = 40, tol = -Inf)
(errs_local <- apply(fit_localCQR$history$beta, 2, function(x)
  norm(matrix(x - betaT), "F")))

tic()
weight <- rep(1/length(tau_K), length(tau_K))
cvmodels <- cv.cqrwenet(
  y = y[1:n],
  x = X[1:n,],
  tau = tau_K,
  weight = weight,
  lambda2 = 0,
  nlambda = nlambda,
  eps = c(1e-2, 1e-2),
  sigma = rep(1.0, nlambda)
)
toc()
ii <- which(cvmodels$lambda == cvmodels$lambda.min)
out <- matrix(cvmodels$cqrwenet.fit$beta[,ii])
sqrt(sum((out - betaT)^2))
# # coef.cutoff <- 1e-1
# # out[abs(out) <= coef.cutoff] <- 0
# coef.cutoff <- 5e-1
# out[abs(out) <= coef.cutoff] <- 0
