# Load library
library(rqPen)
library(FHDQR)
library(FHDCQR)
library(cqrReg)
library(MASS)
library(pracma)
library(igraph) # for graph
library(tictoc)
library(hqreg)
library(glmnet)
source("R/decentralizedQR.R")
source("R/decentralizedCQR.R")
source("R/utils.R")

# Parameters
m <- 10
n <- 2e2
N <- m*n
p <- 1e2
rho <- .1
pc <- 0.3 # the connection probability
K <- 9 # the number of quantile levels
tau_K <- seq(1, K)/(K + 1)
T_inner <- 20
T_outer <- 10
lambda_factor = 1e-4
nlambda = 100L
quiet = F
c0 = 0.013
set.seed(2022)

data <- genData(N, m, p, s, pc, rho = .1, sigma2 = 1, type = "Cauchy", ishomo = TRUE,
                    hetercase = 1)
X <- data$X
y <- data$y
betaT <- data$betaT
graph <- data$graph

Sigma <- toeplitz(rho^seq(0, p - 1, by = 1))
X <- mvrnorm(N, rep(0, p), Sigma)
beta <- matrix(rep(0, p))
beta[1:10] <- 1:10
s <- sum(abs(beta)>0)
# noise <- rnorm(N)
noise <- rcauchy(N)
# noise <- rt(n, 2)
y <- X%*%beta + noise
alphaT <- qcauchy(tau_K)

# test cqrReg
# idx <- 1:n
# lambda_factor <- 1e-3
# nlambda <- 100
# coef.cutoff <- 1e-5
# lambda_max <- max(abs(t(X[idx,]) %*% (y[idx]) / n))
# lambda_array <- exp(seq(log(1), log(lambda_factor), length.out = nlambda))
# lambda_array <- lambda_array[2:length(lambda_array)]
# lambda_array <- lambda_array * lambda_max
# bic_array <- rep(0, length(lambda_array))
# for(ilambda in seq_along(lambda_array)) {
#   lambda <- lambda_array[ilambda]
#   out <- cqr.fit.lasso(X[idx,],y[idx], tau_K,method = "mm", toler = 1e-3, lambda = lambda)
#   out$beta[abs(out$beta)<coef.cutoff] <- 0
#   # gu2020
#   # bic_array[ilambda] <- log(sum(cqr_loss(X[idx,], y[idx], out$beta, matrix(out$b), tau_K))/K) + log(n)*log(log(n))/ n *  sum(abs(out$beta) > 0)
#   # wang2007
#   bic_array[ilambda] <- sum(cqr_loss(X[idx,], y[idx], out$beta,
#                                      matrix(out$b),
#                                      tau_K))/(n*K) + log(n)/ n *  sum(abs(out$beta) > 0)
# }
# plot(bic_array)
# ii <- which.min(bic_array)
# out <- cqr.fit.lasso(X[idx,],y[idx], tau_K,method = "mm", toler = 1e-3, lambda = lambda_array[ii])
# out$beta[abs(out$beta)<coef.cutoff] <- 0
# norm(out$beta - beta, "2")





# pooled
cvmodels <- cv.qraenet(y = y, x = X, tau = 0.5,
                           intercept = FALSE,
                           lambda2 = 0, sigma = 0.05, method = "padmm")

ii <- which(cvmodels$lambda == cvmodels$lambda.min)
beta_pooled <- matrix(cvmodels$qraenet.fit$beta[, ii])
norm(beta_pooled - beta, "2")

# g <- erdos.renyi.game(m, 1/1000)
graph <- sample_gnp(m, pc)
plot(graph)





cvmodels <- cv.qraenet(y = y[1:n], x = X[1:n,], tau = .5,
                       standardize = FALSE,
                       intercept = FALSE,
                       lambda2 = 0)
cvmodels$lambda.1se
m1 <- qraenet(x = X[1:n,], y = y[1:n], tau = .5, pf = rep(1,p), pf2 = rep(1,p),
              standardize = FALSE, intercept = FALSE, lambda = cvmodels$lambda.min,
              lambda2 = 0, sigma = 1.0, method = "padmm")
norm(matrix(m1$beta - beta))

# cvmodels2 <- cv.qraenet(y = y, x = X, tau = .5,
#                        standardize = FALSE,
#                        intercept = FALSE,
#                        lambda2 = 0,parallel = TRUE, mc.cores = getOption("mc.cores", 10L))
# m2 <- qraenet(x = X, y = y, tau = .5, pf = rep(1,p), pf2 = rep(1,p),
#               standardize = FALSE, intercept = FALSE, lambda = cvmodels2$lambda.min,
#               lambda2 = 0, sigma = 1.0, method = "padmm")
# norm(matrix(m2$beta - beta))
T_outer <- 10
tic()
out_deSMR <- decentralizedQR(X, y, s, graph, T_outer, T_inner = 20, c0 = 0.093, tau = 1/2,
                        tau_penalty = 0.2)
toc()
out_deSCQR <- decentralizedCQR(X, y, graph, s, K = 19, T_outer = 10, T_inner = 20,
                             c0 = 0.5)
tic()
out_deSCQR_K9 <- decentralizedCQR(X, y, graph, s, K = 9, T_outer = 10, T_inner = 20,
                             c0 = 0.013)
toc()
err_deSMR <- colSums((out_deSMR - repmat(beta, 1, m))^2)
err_deSCQR <- colSums((out_deSCQR - repmat(beta, 1, m))^2)
err_deSCQR_K9 <- colSums((out_deSCQR_K9 - repmat(beta, 1, m))^2)
plot(err_deSCQR, ylim = c(0.04, 0.08))
points(err_deSMR, col = 2)
points(err_deSCQR_K9, col = 3)
# abline(h = norm(matrix(m2$beta - beta)), col = 2, lty = 2)
abline(h = norm(matrix(m1$beta - beta)), col = 1, lty = 1)

