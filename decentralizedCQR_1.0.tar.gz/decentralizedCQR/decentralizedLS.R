decentralizedLS <- function(X, y, graph, betaT, s, K = 19, T_outer = 10, T_inner = 20,
                             c0 = 0.013, tau_penalty_factor = 1 / 6, nlambda = 100L,
                             lambda_factor = 1e-4,
                             quiet = TRUE)