genData <- function(N, m, p, s, pc, rho = .1, sigma2 = 1, type = "Cauchy", ishomo = TRUE,
                    hetercase = 1) {
  if (!(type %in% c("Cauchy", "Normal", "T2")))
    stop("The error type must be one of Cauchy, Normal and T2.")
  if (ishomo) {
    # Generate homogenous data
    Sigma <- sigma2 * toeplitz(rho^seq(0, p - 1, by = 1))
    X <- MASS::mvrnorm(N, rep(0, p), Sigma)
    betaT <- matrix(rep(0, p))
    betaT[1:s] <- 1:s
    s <- sum(abs(betaT) > 0)
    if (type == "Cauchy")
      noise <- rcauchy(N)
    if (type == "Normal")
      noise <- rnorm(N)
    if (type == "T2")
      noise <- rt(N, 2)
    y <- X %*% betaT + noise

  }
  else {
    # Generate heterogeneous data
    n <- N/m
    if (hetercase == 1) {
      X <- matrix(rep(NA, N * p), ncol = p)
      y <- matrix(rep(NA, N), ncol = 1)
      if (type == "Cauchy")
        noise <- rcauchy(N)
      if (type == "Normal")
        noise <- rnorm(N)
      if (type == "T2")
        noise <- rt(N, 2)
      betaT <- matrix(rep(0, p))
      betaT[1:s] <- 1:s
      sigma2_set <- c(1, 3)
      rho_set <- c(0.1, 0.3)
      for (j in 1:m) {
        idx <- (1 + (j - 1) * n):(j * n)
        sigma2 <- sample(sigma2_set, 1)
        rho <- sample(rho_set, 1)
        Sigma <- sigma2 * toeplitz(rho^seq(0, p - 1, by = 1))
        X[idx,] <- mvrnorm(n, rep(0, p), Sigma)
        y[idx] <- X[idx,] %*% betaT + noise[idx]
      }
    }

  }

  graph <- igraph::sample_gnp(m, pc)
  while(!is_connected(graph)) {
    graph <- igraph::sample_gnp(m, pc)
  }

  return(list(
    X = X,
    y = y,
    betaT = betaT,
    graph = graph
  ))
}



createdir <- function(path, recursive = T) {
  ifelse(!dir.exists(path), dir.create(path, recursive = recursive), FALSE)
}

# for `foreach`
comb <- function(x, ...) {
  lapply(seq_along(x),
    function(i) c(x[[i]], lapply(list(...), function(y) y[[i]])))
}