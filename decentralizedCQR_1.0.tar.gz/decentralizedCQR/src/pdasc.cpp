#include <iostream>
#include <cmath>
// #include <ctime>
// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>

#include "decentralizedCQR.h"
// using namespace arma;

//' @title L1-regularized least square via PDASC
//' @description
//' Modify a string in Rcpp.
//' @name pdasc
//' @param X A n-by-p covariates matrix
//' @param Xt The transpose of X
//' @param b A p-by-1 offset vector
//' @param init A initial solution (defalut: 0)
//' @param N total sample size
//' @param it_com the ``it_com"s iteration
//' @param Lmax the upper factor for the regularization parameter
//' @param Lmin the lower factor for the regularization parameter
//' @param nlambda the length of solution path
//' @examples
//' set.seed(1)
//' p <- 600
//' N <- 100
//' case <- "normal"
//' betaT <- rep(0, p)
//' betaT[1] <- 3
//' betaT[2] <- 1.5
//' betaT[5] <- 2
//' rho <- 0.5
//' data <- gen_data(N, p, betaT, case, rho)
//' x <- data$x
//' y <- data$y
//' b <- t(x)%*%y/N
//' it_com <- 1 # the first iteration
//' Lmax <- 1
//' Lmin <- 1e-4
//' nlambda <- 300
//' t_start <- Sys.time()
//' beta <- pdasc(x, t(x), b, rep(0,p), N, it_com, Lmax, Lmin, nlambda)
//' Sys.time() - t_start
//' plot(betaT)
//' points(beta, pch = 8, col = 2)
//' @export
// [[Rcpp::export]]
arma::vec pdasc(const arma::mat &X, const arma::mat &Xt, arma::vec &b,
                arma::vec init, int N, int it_com, int Lmax,
                double Lmin, int nlambda)
{
  // ------------------------ Arguments checking ------------------------ //
  if (Lmax > 1)
  {
    throw std::invalid_argument("Lmax shall be less than 1.");
  }
  if (b.n_elem != X.n_cols || X.n_cols != Xt.n_rows || X.n_rows != Xt.n_cols)
  {
    throw std::invalid_argument("The dimension of b shall equal to the ncol of X and Xt shall be the transpose of X.");
  }

  // ------------------------ Declare variables ------------------------ //
  int p = b.n_elem;
  int n = X.n_rows;
  arma::mat beta = arma::zeros<arma::mat>(p, nlambda);
  arma::vec as = arma::zeros<arma::vec>(nlambda);

  // double mu = std::min(0.5 * n / std::log(p), std::sqrt(p)); // a criterion for stopping
  double linf = arma::norm(b, "inf"); // the maximal penalty parameter
  arma::vec Lambda_path = arma::exp(arma::linspace(std::log(Lmax),
                                                   std::log(Lmin), nlambda));
  Lambda_path = Lambda_path * linf;
  Lambda_path.shed_row(0); // remove the first element which corresponds to the null solution

  double lam;
  double an;
  int i = 0;
  for (i = 0; i < Lambda_path.n_elem; i++)
  {
    lam = Lambda_path(i);
    init = pdas(X, Xt, b, lam, init);
    beta.col(i) = init;
    arma::uvec idx = arma::find(arma::abs(beta.col(i)) > 0);
    as(i) = idx.n_elem;

    an = std::sqrt(as(i) * std::log(p) / N) + std::pow(as(i), (2 * it_com + 1) / 2.0) *
                                              std::pow(std::log(p) / n, (it_com + 1) / 2.0);
    if (an > 1)
    {
      break; // non-zero elements are too much
    }
    // if (as(i) > mu)
    // {
    //   break; // non-zero elements are too much
    // }
  }

  // discard the unused penalty parameters
  beta.shed_cols(i + 1, beta.n_cols - 1);
  as.shed_rows(i + 1, as.n_rows - 1);

  arma::uvec imode = arma::find(as == mod(as));
  int ii = imode(imode.n_elem - 1); // get the smallest possible penalty parameter
  return beta.col(ii);
}

//' @title L1-regularized least square via PDAS
//' @description
//' Solving
//' \deqn{ 1/(2n)(X\beta)^{2} - b^{T}\beta + \lambda | \beta |_{2}}
//' by one step primal-dual active set algorithm.
//' @name pdas
//' @param X A n-by-p covariates matrix
//' @param b A p-by-1 offset vector
//' @param lambda A regularization parameter
//' @param beta_init An initial estimate
//' @return
//' \item{beta}{the solution}
//' @examples
//' set.seed(1)
//' p <- 600
//' n <- 100
//' case <- "cauchy"
//' betaT <- rep(0, p)
//' betaT[1] <- 3
//' betaT[2] <- 1.5
//' betaT[5] <- 2
//' rho <- 0.5
//' data <- gen_data(n, p, betaT, case, rho)
//' x <- data$x
//' y <- data$y
//' lambda_max <- norm(t(x)%*%y/n, "I")
//' lambda <- lambda_max/2
//' b <- t(x)%*%y/n
//' beta <- pdas(x, t(x), b, lambda, rep(0,p))
//' @export
// [[Rcpp::export]]
arma::vec pdas(const arma::mat &X, const arma::mat &Xt, arma::vec &b, double lambda, arma::vec &beta_init)
{
  int p = beta_init.n_elem;
  int n = X.n_rows;
  arma::vec pd = beta_init + (b - Xt * (X * beta_init) / n);
  arma::uvec Ac = arma::find(arma::abs(pd) > lambda);
  // int s = arma::sum(Ac); // the size of active set
  arma::vec beta = arma::zeros<arma::vec>(p);
  arma::vec dAc = lambda * arma::sign(pd.elem(Ac));
  arma::vec bAc = b.elem(Ac);
  arma::vec rhs = bAc - dAc;
  arma::mat G = Xt.rows(Ac) * X.cols(Ac) / n;
  beta.elem(Ac) = arma::solve(G, rhs);
  return beta;
}
