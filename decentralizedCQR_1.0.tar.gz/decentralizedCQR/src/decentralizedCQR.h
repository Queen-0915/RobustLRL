#ifndef CQR_H
#define CQR_H
#include <iostream>
#include <cmath>
#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]

arma::mat kernel(arma::mat E, arma::vec h);

arma::vec pdas(const arma::mat& X, const arma::mat& Xt, arma::vec& b, double lam, arma::vec& beta_init);

double mod(arma::vec v);

arma::vec pdasc(const arma::mat& X, const arma::mat& Xt, arma::vec& b,
                arma::vec init, int N, int it_com, int Lmax = 1,
                double Lmin = 1e-4, int nlambda = 300);

double quantile_lossCPP(arma::vec x, double tau);

double cqr_loss_cpp(arma::mat X, arma::vec y, arma::vec beta, arma::vec alpha, arma::vec& tau);

arma::uvec calN_j_cpp(int n, int j);

arma::vec pmax_arma(arma::vec x, double bound);

arma::vec soft_thresholding_cpp(arma::vec x, double t);

#endif
