#!/bin/bash

#PBS -N R_job
### use one node for this job
##PBS -l nodes=1:ppn=40
##PBS -q pnode
#PBS -l nodes=1:ppn=24
### send mail
#PBS -M chency1997@ruc.edu.cn
#PBS -m eba
### set output files
#PBS -o sim_iterations_1.stdout
#PBS -e sim_iterations_1.stderr

cd $PBS_O_WORKDIR
module load anaconda/5.3.0

Rscript Sims/sim_iterations.R