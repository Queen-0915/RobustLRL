decentralizedQR <- function(X, y, s, g, V, T_inner = 20, c0 = 0.093, tau = 1/2,
                             tau_penalty = 0.2) {
  m <- length(igraph::V(g))
  p <- ncol(X)
  N <- nrow(X)
  n <- N/m

  B_out <- matrix(rep(0, m*p), nrow = p)
  B_inner <- matrix(rep(0, m*p), nrow = p)
  B_init <- matrix(rep(0, m*p), nrow = p)
  yt <- matrix(rep(0, N))
  rho <- matrix(rep(0, m))
  omega <- matrix(rep(0,m))
  tau_penalty <- eig(t(X[1:n,])%*%X[1:n,])[1]*0.05/n # Cauchy
  # tau_penalty <- eig(t(X[1:n,])%*%X[1:n,])[1]*0.02/n # t2
  # tau_penalty <- eig(t(X[1:n,])%*%X[1:n,])[1]*0.03/n # t2
  # tau_penalty <- eig(t(X[1:n,])%*%X[1:n,])[1]*0.05/n # t2
  # tau_penalty = 0.2 # Normal
  # tau_penalty <- eig(t(X[1:n,])%*%X[1:n,])[1]*0.05/n # Normal
  c0 = 0.1 # t2 & Normal
  for(j in 1:m) {
    idx <- calN_j(n, j)
    rho[j] <- eig(t(X[idx,])%*%X[idx,]/n)[1]
    omega[j] <- 1/(2*tau_penalty*length(neighbors(g, j)) + rho[j])
  }

  # Initial points
  for(j in 1:m) {
    # cat(j)
    idx <- calN_j(n, j)
    # tau <- .5
    cvmodels <- cv.qraenet(y = y[idx], x = X[idx,], tau = tau,
                           standardize = FALSE,
                           intercept = FALSE,
                           lambda2 = 0)
    sigma <-
    m1 <- qraenet(x = X[idx,], y = y[idx], tau = tau, pf = rep(1,p), pf2 = rep(1,p),
                  standardize = FALSE, intercept = FALSE,
                  lambda = cvmodels$lambda.min,
                  lambda2 = 0, sigma = 1.0, method = "padmm")
    B_init[,j] <- matrix(m1$beta)
  }

  B_out <- B_init
  for(v in 1:V) {
    # Construct pseudo responses # This matters
    # hv <- 3*(sqrt(s*log(N)/N) + s^{-1/2}*(c0*s^2*log(N)/n)^{(v)/2})
    hv <- (sqrt(s*log(N)/N) + s^{-1/2}*(c0*s^2*log(N)/n)^{(v)/2})
    for(j in 1:m) {
      idx <- calN_j(n, j)
      fhj <- fh(X[idx,], y[idx], B_out[,j], hv)
      cat(fhj, "\t")
      yt[idx] <- X[idx,]%*%B_out[,j] - 1/fhj*((y[idx]<X[idx,]%*%B_out[,j]) - tau)
    }
    boxplot(yt)
    cat("\n")



    # lambda <- C0*(sqrt(log(N)/N) + sqrt(s*log(N)/n)*s^(- 1/2)*(c0*s^2*log(N)/n)^(v/2))
    # lambda_max <- min(max(abs(t(X)%*%(yt)/N)), lambda)

    # if(v == 1) lambda_max <- max(abs(t(X)%*%(yt)/N))
    # if(v > 1) lambda_max <- lambda + lambda/10




    N1 <- 50
    mu <-
      min(n / log(p), sqrt(N)) # Contrains by the relationship of n, p and s as indicated by the theorems.
    as <- rep(NA, N1 - 1)
    lambda_max <- max(abs(t(X)%*%(yt)/N))
    lambda_array <- exp(seq(log(1), log(1e-4), length.out = N1))
    lambda_array <- lambda_array[2:length(lambda_array)]
    lambda_array <- lambda_array*lambda_max
    bic_array <- rep(0, length(lambda_array))
    kk <- 0

    for(ilambda in 1:length(lambda_array)) {

      lambda <- lambda_array[ilambda]

      B_inner <- B_out
      P <- matrix(rep(0, p*m), nrow = p)
      for(t in 1:T_inner) {
        B_inner_old <- B_inner
        for(j in 1:m) {
          # loop over the network
          # cat(j)
          idx <- calN_j(n, j)
          neighbors_j <- neighbors(g, j)
          P[,j] <- P[,j] + tau_penalty*rowSums1(B_inner[,j] - B_inner[,neighbors_j])
          # tmp <- omega[j]*(
          #   rho[j]*B_inner_old[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner_old[,j] - yt[idx]) -
          #     P[,j] + tau_penalty*rowSums1(B_inner_old[,j] + B_inner_old[,neighbors_j])
          # )
          tmp <- omega[j]*(
            rho[j]*B_inner[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner[,j] - yt[idx]) -
              P[,j] + tau_penalty*rowSums1(B_inner[,j] + B_inner[,neighbors_j])
          )
          B_inner[,j] <- soft_thresholding(tmp, lambda*omega[j])
        }
      }
      # as[ilambda] <- sum(abs(B_inner[,1])>0)
      # kk <- kk + 1
      # if(as[ilambda] == 0) {
      #   an = 0
      # }
      # if(as[ilambda] > 0) {
      #   an <- sqrt(as[ilambda] * log(N) / N) + as[ilambda]^(-1 / 2.0) *
      #     (c0*as[ilambda]^2*log(N) / n)^((v + 1) / 2.0)
      # }

      # if(an > 1){
      #   break
      # }
      # if(as[ilambda] > mu){
      #   break
      # }

      # for(j in 1:m) {
      #   # cat(j, "\n")
      #   idx <- calN_j(n, j)
      #   # bic_array[ilambda] <- bic_array[ilambda] +
      #   #   n*log(1/n*sum(check_loss(y[idx] - X[idx,]%*%B_inner[,j, drop = FALSE], tau))) +
      #   #   log(n)*sum(abs(B_inner[,j])>0)
      #   bic_array[ilambda] <- bic_array[ilambda] +
      #     n*log(1/n*sum((yt[idx] - X[idx,]%*%B_inner[,j, drop = FALSE])^2)) +
      #     log(n)*sum(abs(B_inner[,j])>0)
      # }
      # bic_array[ilambda] <- N*log(1/N*sum((yt - X%*%B_inner[,1, drop = FALSE])^2)) +
      #   log(N)*sum(abs(B_inner[,1])>0) # This is important
      bic_array[ilambda] <- N*log(1/N*sum(check_loss(y - X%*%B_inner[,1, drop = FALSE], tau))) +
        log(N)*sum(abs(B_inner[,1])>0) # This is important



    }
    # as <- as[1:kk]
    # plot(as)
    # ii <- (1:length(as))[as == mod(as)]
    # ii <- ii[length(ii)]
    # lambda <- lambda_array[ii]

    # find the lambda such whose bic is the minimal
    ilambda <- which.min(bic_array)
    lambda <- lambda_array[ilambda]
    cat("lambda = ", lambda, "\n\n")
    B_inner <- B_out
    P <- matrix(rep(0, p*m), nrow = p)
    for(t in 1:T_inner) {
      B_inner_old <- B_inner
      for(j in 1:m) {
        # loop over the network
        # cat(j)
        idx <- calN_j(n, j)
        neighbors_j <- neighbors(g, j)
        P[,j] <- P[,j] + tau_penalty*rowSums1(B_inner[,j] - B_inner[,neighbors_j])
        # tmp <- omega[j]*(
        #   rho[j]*B_inner_old[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner_old[,j] - yt[idx]) -
        #     P[,j] + tau_penalty*rowSums1(B_inner_old[,j] + B_inner_old[,neighbors_j])
        # )
        tmp <- omega[j]*(
          rho[j]*B_inner[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner[,j] - yt[idx]) -
            P[,j] + tau_penalty*rowSums1(B_inner[,j] + B_inner[,neighbors_j])
        )
        B_inner[,j] <- soft_thresholding(tmp, lambda*omega[j])
      }
      cat(norm(B_inner[,3] - beta, "2")^2, "\t\n")
    }

    # plot(B_inner[,1])

    norm(B_init[,3] - beta, "2")^2

    B_out <- B_inner

    # cat(B_out[,1],"\n\n")

  }
  return(B_out)
}

# apply(B_out, 2, function(x) norm(matrix(x - beta)))
rowSums1 <- function(x) {
  if(is.null(dim(x))) {
    return(x)
  }
  return(rowSums(x))
}


calN_j <- function(n, j) {
  return((n*(j - 1) + 1):(n*j))
}

fh <- function(X, y, beta, h) {
  kernel <- function(x) {
    (-315/64*x^6+ 735/64*x^4-525/64*x^2+ 105/64)*(abs(x)<=1)
  }
  n <- nrow(X)
  sum(kernel((y - X%*%beta)/h))/n/h
}

soft_thresholding <- function(x, t) {
  # pmax(x - t, 0) + pmax(-x - t, 0)
  pmax(x - t, 0) - pmax(-x - t, 0)
  # return(list(pmax(x - t, 0) - pmax(-x - t, 0),
  #             sign(x)*pmax((abs(x) - t), 0))
  # )
  # pmax(1 - t/x, 0)*x
  # sign(x)*pmax((abs(x) - t), 0)
}


check_loss <- function(x, tau) {
  # pmax(tau*x, 0) - pmax(-(1-tau)*x, 0)
  (abs(x) + (2 * tau - 1) * x) * 0.5
}


mod <- function(as) {
  return(unique(as)[which.max(purrr::map(unique(as), ~ sum(as == .)))])
}

