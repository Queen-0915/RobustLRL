source("decentralizedCQR.R")

decentralizedLASSO <- function(X, y, graph, betaT, T_inner = 500,
                               tau_penalty_factor = 1 / 6, nlambda = 100L,
                               lambda_factor = 1e-4,
                               quiet = TRUE) {
  # Parameters
  m <- length(igraph::V(graph)) # the number of nodes
  p <- ncol(X) # dimension
  N <- nrow(X) # sample size
  n <- N / m # local sample size

  tau_penalty_beta <- pracma::eig(t(X[1:n,]) %*% X[1:n,])[1] / n * tau_penalty_factor


  B_out <- matrix(rep(0, m * p), nrow = p)
  B_init <- matrix(rep(0, m * p), nrow = p)

  rho <- matrix(rep(0, m)) # the step length for each node
  omega <- matrix(rep(0, m)) # for threshold of the beta

  # cache omega
  for (j in 1:m) {
    idx <- calN_j(n, j)
    rho[j] <- eig(t(X[idx,]) %*% X[idx,] / n)[1]
    omega[j] <- 1 / (2 *
      tau_penalty_beta *
      length(neighbors(graph, j)) + rho[j])
  }

  # Initial points
  for (j in 1:m) {
    # get the index set for node j
    idx <- calN_j(n, j)

    # Method I: Initial with Lasso
    cvmodels <- cv.glmnet(y = y[idx], x = X[idx,],
                          intercept = FALSE)

    ii <- which(cvmodels$lambda == cvmodels$lambda.min)
    out <- matrix(cvmodels$glmnet.fit$beta[, ii])
    B_init[, j] <- out
  }
  error_init <- sqrt(mean(colSums((B_init - repmat(betaT, 1, m))^2)))
  if (!quiet) {
    cat("The RMSE for the initial estimate is",
        error_init
      ,
        "\n")
  }




  # Choose the tunning parameter $\lambda_{N, v}$ with BIC
  lambda_max <- max(abs(t(X) %*% (y) / N))
  lambda_array <- exp(seq(log(1), log(lambda_factor), length.out = nlambda))
  lambda_array <- lambda_array[2:length(lambda_array)]
  lambda_array <- lambda_array * lambda_max
  bic_array <- rep(0, length(lambda_array))

  for (ilambda in 1:length(lambda_array)) {

    lambda <- lambda_array[ilambda]

    B_inner <- B_init
    P_beta <- matrix(rep(0, p * m), nrow = p)
    for (t in 1:T_inner) {
      B_inner_old <- B_inner
      for (j in 1:m) {
        # loop over the network
        idx <- calN_j(n, j)
        neighbors_j <- neighbors(graph, j)
        P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] -
                                                                   B_inner_old[, neighbors_j])

        tmp <- omega[j] * (
          rho[j] * B_inner_old[, j] -
            1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner_old[, j] - y[idx]) -
            P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] + B_inner_old[, neighbors_j])
        )
        B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])
      }
    }
    # bic_array[ilambda] <- N * log(1 / (N) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
    #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
    #   log(N) * sum(abs(B_inner[, 3]) > 0) # This is important

    # bic_array[ilambda] <- 2 * N * log(1 / (2*N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
    #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
    #   log(N) * sum(abs(B_inner[, 3]) > 0) # This is important

    # BICHL
    # bic_array[ilambda] <- log(1 / (2*N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
    #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
    #   log(N) * log(log(N))/ N * sum(abs(B_inner[, 3]) > 0) # This is important

    # BIC
    # bic_array[ilambda] <- 1 / (N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
    #                                                    A_inner[, 3, drop = FALSE], tau_K)) +
    #   log(N) * log(log(N))/ N * sum(abs(B_inner[, 3]) > 0) # This is important

    # j <- 3
    # idx <- calN_j(n, j)
    # bic_array[ilambda] <- 1 / (n*K) * sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
    #                                                    A_inner[, j, drop = FALSE], tau_K)) +
    #   log(n)/ n * sum(abs(B_inner[, j]) > 0) # This is important

    # for(j in 1:m) {
    #     idx <- calN_j(n, j)
    #     bic_array[ilambda] <- bic_array[ilambda] + 1 / (n*K) * sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
    #                                                    A_inner[, j, drop = FALSE], tau_K)) +
    #   log(n)/ n * sum(abs(B_inner[, j]) > 0) # This is important
    # }

    # shat <- 0
    # for(j in 1:m) {
    #     idx <- calN_j(n, j)
    #     bic_array[ilambda] <- bic_array[ilambda] +  sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
    #                                                    A_inner[, j, drop = FALSE], tau_K))
    #   shat <- max(shat, sum(abs(B_inner[, j]) > 0))
    # }
    # bic_array[ilambda] <- 1 / (N*K) * bic_array[ilambda] + log(N)/ N *  shat# This is important


    # gu2020 wang2009
    shat <- 0
    for (j in 1:m) {
      idx <- calN_j(n, j)
      bic_array[ilambda] <- bic_array[ilambda] + sum((y[idx] - X[idx,] %*% B_inner)^2)
      shat <- max(shat, sum(abs(B_inner[, j]) > 0))
    }
    bic_array[ilambda] <- log(bic_array[ilambda]) + log(N) * log(log(N)) / N * shat # This is important

    # j <- 1
    # idx <- calN_j(n, j)
    # bic_array[ilambda] <- 1 / (n*K) * sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
    #                                                    A_inner[, j, drop = FALSE], tau_K)) +
    #   log(n)/ n * sum(abs(B_inner[, j]) > 0) # This is important

  }

  # find the lambda such whose bic is the minimal
  ilambda <- which.min(bic_array)
  lambda <- lambda_array[ilambda]

  if (!quiet) {
    cat("lambda =", lambda, "\n")
  }

  B_inner <- B_init
  P_beta <- matrix(rep(0, p * m), nrow = p)
  errors_inner <- rep(NA, T_inner)
  for (t in 1:T_inner) {
    # Inner iterations

    B_inner_old <- B_inner
    for (j in 1:m) {
      # Loop over the network
      idx <- calN_j(n, j)
      neighbors_j <- neighbors(graph, j)
      P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] - B_inner_old[, neighbors_j])

      tmp <- omega[j] * (
        rho[j] * B_inner_old[, j] -
          1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner_old[, j] - y[idx]) -
          P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] + B_inner_old[, neighbors_j])
      )
      B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])


    }
    errors_inner[t] <- sqrt(mean(colSums((B_inner - repmat(betaT, 1, m))^2)))
    if (!quiet) {
      cat(errors_inner[t], "\t\n")
    }
  }


  return(list(
    B = B_inner,
    history = list(errors_inner = c(error_init, as.numeric(errors_inner)),
                   errors_outer = c(error_init, errors_inner[T_inner,]))
  ))

}