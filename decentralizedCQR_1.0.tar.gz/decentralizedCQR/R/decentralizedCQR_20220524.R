decentralizedCQR <- function(X, y, graph, s, K = 19, T_outer = 15, T_inner = 20,
                             c0 = 0.013, tau_penalty_alpha_factor = 0.1,
                             tau_penalty_beta_factor = 0.05, nlambda = 100L,
                             lambda_factor = 1e-4,
                             quiet = TRUE) {
  # Parameters
  m <- length(igraph::V(graph)) # the number of nodes
  p <- ncol(X) # dimension
  N <- nrow(X) # sample size
  n <- N / m # local sample size
  tau_K <- seq(1, K) / (K + 1) # quantile levels

  # tau_penalty_alpha <- 0.01 # Lagrangian penalty parameter for alpha
  tau_penalty_alpha <- 0.5 # Lagrangian penalty parameter for alpha
  # tau_penalty_alpha <- 1 # Lagrangian penalty parameter for alpha
  # tau_penalty_beta_factor <- 0.05
  # tau_penalty_beta_factor <- 0.1
  # tau_penalty_beta_factor <- 0.5
  # tau_penalty_beta <- pracma::eig(t(X[1:n,]) %*% X[1:n,])[1] * tau_penalty_beta_factor / n # Lagrangian penalty parameter for beta
  # tau_penalty_beta <- 1
  tau_penalty_beta <- 0.5
  errors_inner <- matrix(rep(NA, T_inner*T_outer), nrow = T_inner)


  A_out <- matrix(rep(0, m * K), nrow = K)
  A_init <- matrix(rep(0, m * K), nrow = K)
  B_out <- matrix(rep(0, m * p), nrow = p)
  B_init <- matrix(rep(0, m * p), nrow = p)

  yt <- matrix(rep(0, N)) # tramsformed y
  zt <- matrix(rep(0, N * K), ncol = K) # transformed z
  rho <- matrix(rep(0, m)) # the step length for each node
  omega <- matrix(rep(0, m)) # for threshold of the beta

  # cache omega
  for (j in 1:m) {
    idx <- calN_j(n, j)
    rho[j] <- 1.01*eig(t(X[idx,]) %*% X[idx,] / n)[1]
    # rho[j] <- 1.2*eig(t(X[idx,]) %*% X[idx,] / n)[1]
    # omega[j] <- 1 / (2 *
    #   tau_penalty_beta *
    #   length(neighbors(graph, j)) + rho[j])
        omega[j] <- 1 / (2 *
      tau_penalty_beta *
      length(neighbors(graph, j)) + rho[j])
  }

  # Initial points # Initial points matters
  tic()
  for (j in 1:m) {
    # get the index set for node j
    idx <- calN_j(n, j)

    # Method I: Initial with the CQR estimator
    # cvmodels <- cv.cqrwenet(y = y[idx], x = X[idx,],
    #                         tau = quantile_levels,
    #                         lambda_factor = 0.05,
    #                         weight = rep(1/length(quantile_levels), length(quantile_levels)),
    #                         standardize = FALSE,
    #                         eps = c(1e-2, 1e-2),
    #                         lambda2 = 0,
    #                         sigma = rep(1, 100), mc.cores = 10)
    # ii <- which(cvmodels$lambda== cvmodels$lambda.1se)
    # B_init[, j] <- matrix(cvmodels$cqrwenet.fit$beta[,ii])
    # A_init[, j] <- matrix(cvmodels$cqrwenet.fit$alpha[,ii])

    # Method II: Initial with the QR estimator
    cvmodels <- cv.qraenet(y = y[idx], x = X[idx,], tau = 0.5,
                           intercept = FALSE,
                           lambda2 = 0, sigma = 1.0, method = "padmm")

    ii <- which(cvmodels$lambda == cvmodels$lambda.min)
    B_init[, j] <- matrix(cvmodels$qraenet.fit$beta[, ii])
    A_init[, j] <- matrix(quantile(y[idx] - X[idx,] %*% B_init[, j], tau_K))

    # Method III: rqPen
    # cvmodels <- cv.rq.pen(X[idx,],y[idx], intercept = F, tau = 0.5)
    # lambda <- cvmodels$lambda.min
    # B_init[, j] <- LASSO.fit(y[idx], X[idx,], tau = 0.5, lambda = lambda, intercept = F, coef.cutoff=1e-08)
    # A_init[, j] <- matrix(quantile(y[idx] - X[idx,] %*% B_init[, j], tau_K))
  }
  toc()


  B_out <- B_init
  A_out <- A_init
  for (v in 1:T_outer) {
    # Outer iterations

    # The bandwidth for the v-th outer iteration. Here c0 is chosen to ensure c0 * s^2 * log(N) / n < 1.
    # c0 <- 0.013
    if(v > 1) {
      hv <- (sqrt(s * log(N) / N) + s^{ -1 / 2 } * (c0*s^2 * log(N) / n)^{ (v) / 2 })
    } else {
      hv <- 0.5*s^{ -1 / 2 } * (s^2 * log(N) / n)^{ (1) / 2 }
    }

    if(!quiet){
      cat("Outer iteration: v =", v, "hv =", hv, "\n")
    }
    # Construct pseudo responses # This matters
    for (j in 1:m) {
      idx <- calN_j(n, j)
      E <- pracma::repmat(y[idx] - X[idx,] %*% B_out[, j], 1, K) - pracma::repmat(t(A_out[, j]), n, 1)
      fhat <- fh_vec(E, matrix(rep(hv, K), ncol = 1))
      if(!quiet) {
        cat(fhat, "\n\n")
      }

      ztmp <- (E <= 0) - pracma::repmat(t(tau_K), n, 1)
      yt[idx] <- X[idx,] %*% B_out[, j] - 1 / sum(fhat) * rowSums(ztmp)
      zt[idx,] <- pracma::repmat(t(A_out[, j]), n, 1) - ztmp / pracma::repmat(t(fhat), n, 1)
    }



    # Choose the tunning parameter $\lambda_{N, v}$ with BIC
    lambda_max <- max(abs(t(X) %*% (yt) / N))
    lambda_array <- exp(seq(log(1), log(lambda_factor), length.out = nlambda))
    lambda_array <- lambda_array[2:length(lambda_array)]
    lambda_array <- lambda_array * lambda_max
    bic_array <- rep(0, length(lambda_array))

    for (ilambda in 1:length(lambda_array)) {

      lambda <- lambda_array[ilambda]

      A_inner <- A_out
      B_inner <- B_out
      P_beta <- matrix(rep(0, p * m), nrow = p)
      P_alpha <- matrix(rep(0, K * m), nrow = K)
      for (t in 1:T_inner) {
        A_inner_old <- A_inner
        B_inner_old <- B_inner
        for (j in 1:m) {
          # loop over the network
          idx <- calN_j(n, j)
          neighbors_j <- neighbors(graph, j)
          P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] -
                                                                     B_inner_old[, neighbors_j])
          P_alpha[, j] <- P_alpha[, j] + tau_penalty_alpha * rowSums1(A_inner_old[, j] -
                                                                        A_inner_old[, neighbors_j])

          tmp <- omega[j] * (
            rho[j] * B_inner_old[, j] -
              1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner_old[, j] - yt[idx]) -
              P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] + B_inner_old[, neighbors_j])
          )
          B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])
          A_inner[, j] <- 1 / (1 + 2 * tau_penalty_alpha * m * length(neighbors_j)) * (
            colSums(zt[idx,]) / n - m * P_alpha[, j] + 2 *
              tau_penalty_alpha *
              rowSums1(A_inner_old[, j] +
                         A_inner_old[, neighbors_j])
          )
        }
      }
      # bic_array[ilambda] <- N * log(1 / (N) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
      #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
      #   log(N) * sum(abs(B_inner[, 3]) > 0) # This is important

      # bic_array[ilambda] <- 2 * N * log(1 / (2*N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
      #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
      #   log(N) * sum(abs(B_inner[, 3]) > 0) # This is important

      # BICHL
      # bic_array[ilambda] <- log(1 / (2*N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
      #                                                    A_inner[, 3, drop = FALSE], tau_K))) +
      #   log(N) * log(log(N))/ N * sum(abs(B_inner[, 3]) > 0) # This is important

      # BIC
      # bic_array[ilambda] <- 1 / (N*K) * sum(cqr_loss(X, y, B_inner[, 3, drop = FALSE],
      #                                                    A_inner[, 3, drop = FALSE], tau_K)) +
      #   log(N) * log(log(N))/ N * sum(abs(B_inner[, 3]) > 0) # This is important

      # j <- 3
      # idx <- calN_j(n, j)
      # bic_array[ilambda] <- 1 / (n*K) * sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
      #                                                    A_inner[, j, drop = FALSE], tau_K)) +
      #   log(n)/ n * sum(abs(B_inner[, j]) > 0) # This is important

      for(j in 1:m) {
          idx <- calN_j(n, j)
          bic_array[ilambda] <- bic_array[ilambda] + 1 / (n*K) * sum(cqr_loss(X[idx,], y[idx], B_inner[, j, drop = FALSE],
                                                         A_inner[, j, drop = FALSE], tau_K)) +
        log(n)/ n * sum(abs(B_inner[, j]) > 0) # This is important
      }

    }

    # find the lambda such whose bic is the minimal
    ilambda <- which.min(bic_array)
    lambda <- lambda_array[ilambda]

    if(!quiet) {
      cat("lambda =", lambda, "\n")
    }

    B_inner <- B_out
    A_inner <- A_out
    P_beta <- matrix(rep(0, p * m), nrow = p)
    P_alpha <- matrix(rep(0, K * m), nrow = K)
    for (t in 1:T_inner) {
      # Inner iterations

      B_inner_old <- B_inner
      A_inner_old <- A_inner
      for (j in 1:m) {
        # Loop over the network
        idx <- calN_j(n, j)
        neighbors_j <- neighbors(graph, j)
        P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] - B_inner_old[, neighbors_j])
        P_alpha[, j] <- P_alpha[, j] + tau_penalty_alpha * rowSums1(A_inner_old[, j] - A_inner_old[, neighbors_j])

        tmp <- omega[j] * (
          rho[j] * B_inner_old[, j] -
            1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner_old[, j] - yt[idx]) -
            P_beta[, j] + tau_penalty_beta * rowSums1(B_inner_old[, j] + B_inner_old[, neighbors_j])
        )
        B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])
        A_inner[, j] <- 1 / (1 + 2 * tau_penalty_alpha * m * length(neighbors_j)) * (
          colSums(zt[idx,]) / n - m * P_alpha[, j] + 2 *
            tau_penalty_alpha *
            rowSums1(A_inner_old[, j] +
                       A_inner_old[, neighbors_j])
        )
      }
      errors_inner[t, v] <- mean(colSums((B_inner - repmat(beta, 1, m))^2))
      if(!quiet) {
        cat(errors_inner[t, v], "\t\n")
      }
    }

    B_out <- B_inner
    A_out <- A_inner
  }


  return(list(
    B = B_out,
    history = list(errors_inner = errors_inner,
                   errors_outer = errors_inner[T_inner,])
  ))
}


rowSums1 <- function(x) {
  if (is.null(dim(x))) {
    return(x)
  }
  return(rowSums(x))
}


calN_j <- function(n, j) {
  return((n * (j - 1) + 1):(n * j))
}

fh_vec <- function(E, h) {

  kernel <- function(x) {
    (-315 / 64 * x^6 + 735 / 64 * x^4 - 525 / 64 * x^2 + 105 / 64) * (abs(x) <= 1)
  }

  E <- E / pracma::repmat(t(h), nrow(E), 1)

  return(matrix(apply(kernel(E), 2, mean), ncol = 1) / h)
}

soft_thresholding <- function(x, t) {
  pmax(x - t, 0) - pmax(-x - t, 0)
  # sign(x)*pmax(abs(x) - t, 0)
}


check_loss <- function(x, tau) {
  (abs(x) + (2 * tau - 1) * x) * 0.5
}

cqr_loss <- function(X, y, beta, alpha, tau) {
  s <- 0
  for (i in seq_along(tau)) {
    s <- s + check_loss(y - X %*% beta - alpha[i], tau[i])
  }
  return(s)
}


mod <- function(as) {
  return(unique(as)[which.max(purrr::map(unique(as), ~sum(as == .)))])
}

