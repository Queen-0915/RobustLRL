#' @export
genData <- function(N, m, p, s, pc, rho = .1, sigma2 = 1, type = "Cauchy", ishomo = TRUE,
                    hetercase = 1) {
  if (!(type %in% c("Cauchy", "Normal", "T2")))
    stop("The error type must be one of Cauchy, Normal and T2.")
  if (ishomo) {
    # Generate homogenous data
    Sigma <- sigma2 * toeplitz(rho^seq(0, p - 1, by = 1))
    X <- MASS::mvrnorm(N, rep(0, p), Sigma)
    betaT <- matrix(rep(0, p))
    betaT[1:s] <- 1:s
    s <- sum(abs(betaT) > 0)
    if (type == "Cauchy")
      noise <- rcauchy(N)
    if (type == "Normal")
      noise <- rnorm(N)
    if (type == "T2")
      noise <- rt(N, 2)
    y <- X %*% betaT + noise

  }
  else {
    # Generate heterogeneous data
    n <- N/m
    if (hetercase == 1) {
      X <- matrix(rep(NA, N * p), ncol = p)
      y <- matrix(rep(NA, N), ncol = 1)
      if (type == "Cauchy")
        noise <- rcauchy(N)
      if (type == "Normal")
        noise <- rnorm(N)
      if (type == "T2")
        noise <- rt(N, 2)
      betaT <- matrix(rep(0, p))
      betaT[1:s] <- 1:s
      sigma2_set <- c(1, 3)
      rho_set <- c(0.1, 0.3)
      for (j in 1:m) {
        idx <- (1 + (j - 1) * n):(j * n)
        sigma2 <- sample(sigma2_set, 1)
        rho <- sample(rho_set, 1)
        Sigma <- sigma2 * toeplitz(rho^seq(0, p - 1, by = 1))
        X[idx,] <- MASS::mvrnorm(n, rep(0, p), Sigma)
        y[idx] <- X[idx,] %*% betaT + noise[idx]
      }
    }
    if (hetercase == 2) {
      # Generate heterogeneous data
      Sigma <- sigma2 * toeplitz(rho^seq(0, p - 1, by = 1))
      X <- MASS::mvrnorm(N, rep(0, p), Sigma)
      betaT <- matrix(rep(0, p))
      betaT[1:s] <- 1:s
      s <- sum(abs(betaT) > 0)
      idx <- ceiling(runif(m, 0, 3))
      noise <- (rep(idx == 1, each = n))*rcauchy(N) + (rep(idx == 2, each = n))*rnorm(N) + (rep(idx == 3, each = n))*rt(N, 2)
      y <- X %*% betaT + noise
    }
  }

  graph <- igraph::sample_gnp(m, pc)
  while(!is_connected(graph)) {
    graph <- igraph::sample_gnp(m, pc)
  }

  return(list(
    X = X,
    y = y,
    betaT = betaT,
    graph = graph
  ))
}


#' @export
createdir <- function(path, recursive = T) {
  ifelse(!dir.exists(path), dir.create(path, recursive = recursive), FALSE)
}

# for `foreach`
#' @export
comb <- function(x, ...) {
  lapply(seq_along(x),
    function(i) c(x[[i]], lapply(list(...), function(y) y[[i]])))
}

#' @title Compute F1 score of two set
#' @description Compute \eqn{F_1} score of two set. Note that \eqn{F_1} score is
#' symmetric.
#' @name computeF1
#' @param esupp the estimated support
#' @param supp the true support
#' @return A list consists of
#' \item{f1}{the computed F1 score}
#' \item{precision}{the precision}
#' \item{recall}{the recall}
#' \item{fp}{false positve}
#' \item{fn}{false negative}
#' @references
#' \url{https://en.wikipedia.org/wiki/F-score}
#' @export
computeF1 <- function(esupp, supp) {
  tp <- length(intersect(esupp, supp))
  fp <- length(setdiff(esupp, supp))
  fn <- length(setdiff(supp, esupp))
  precision <- tp/(tp + fp)
  recall <- tp/(tp + fn)
  f1 <- 2*(precision*recall)/(precision+recall)
  if(precision == 0 || recall == 0) {
    f1 <- 0
  }
  return(list(f1 = f1,
              precision = precision,
              recall = recall,
              fp = fp,
              fn = fn))
}

#' @export
computeError <- function(x, y, type = "F") {
  stopifnot(is.numeric(x) && is.numeric(y))
  if((length(x) != length(y)) && is.matrix(x)) {
    m <- ncol(x)
    sqrt(norm(x - matrix(rep(y, ncol(x)), ncol = ncol(x)), type = type)^2/m)
  } else {
    stopifnot(length(x)==length(y))
    return(drop(norm(matrix(x - y), type =  type)))
  }
}


#' @export
bic.hqreg <- function(X, y, tau_K, nlambda = 100) {
  p <- ncol(X)
  K <- length(tau_K)
  N <- nrow(X)
  bic_array <- rep(NA, nlambda)
  out <- hqreg::hqreg(X, y, method = "quantile", tau = mean(tau_K), nlambda = nlambda)
  for(ilambda in 1:ncol(out$beta)) {
    beta <- out$beta[,ilambda]
    b <- quantile(y - X%*%beta[2:(p+1)], tau_K)
    bic_array[ilambda] <-  cqr_loss_cpp(X, y, beta[2:(p+1)], b, tau_K)/ K/ N + log(N)*log(log(N))/N*sum(abs(beta[2:(p+1)])>0)
  }
  ii <- which.min(bic_array)
  beta_pooled <- out$beta[,ii]
  beta_pooled <- beta_pooled[2:(p + 1)]
  return(beta_pooled)
}
