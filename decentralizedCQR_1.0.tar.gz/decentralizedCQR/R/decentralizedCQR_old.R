decentralizedCQR <- function(X, y, graph, s, K = 19, T_outer = 10, T_inner = 20,
                              c0 = 0.5, tau_penalty_alpha = 0.1,
                             tau_penalty_beta = 0.2) {
  m <- length(igraph::V(graph))
  p <- ncol(X)
  N <- nrow(X)
  n <- N / m
  tau_K <- seq(1, K)/(K + 1)

  A_out <- matrix(rep(0, m*K), nrow = K)
  A_init <- A_out
  A_init <- A_out
  B_out <- matrix(rep(0, m * p), nrow = p)
  B_inner <- B_out
  B_init <- B_out

  tau_penalty_alpha <- K/n*0.1
  tau_penalty_beta <- pracma::eig(t(X[1:n,]) %*% X[1:n,])[1] * 0.05 / n

  # c0 = 0.2 # t2 & Normal

  yt <- matrix(rep(0, N))
  zt <- matrix(rep(0, N*K), ncol = K)
  rho <- matrix(rep(0, m))
  omega <- matrix(rep(0, m))

  for (j in 1:m) {
    idx <- calN_j(n, j)
    rho[j] <- eig(t(X[idx,]) %*% X[idx,] / n)[1]
    omega[j] <- 1 / (2 * tau_penalty_beta * length(neighbors(graph, j)) + rho[j])
  }

  # Initial points
  for (j in 1:m) {
    # cat(j, "\n")

    idx <- calN_j(n, j)

    # cvmodels <- cv.cqrwenet(y = y[idx], x = X[idx,],
    #                         tau = quantile_levels,
    #                         lambda_factor = 0.05,
    #                         weight = rep(1/length(quantile_levels), length(quantile_levels)),
    #                         standardize = FALSE,
    #                         eps = c(1e-2, 1e-2),
    #                         lambda2 = 0,
    #                         sigma = rep(1, 100), mc.cores = 10)
    # ii <- which(cvmodels$lambda== cvmodels$lambda.1se)
    # B_init[, j] <- matrix(cvmodels$cqrwenet.fit$beta[,ii])
    # A_init[, j] <- matrix(cvmodels$cqrwenet.fit$alpha[,ii])
    # tic()
    cvmodels <- cv.qraenet(y = y[idx], x = X[idx,], tau = 0.5,
                           standardize = FALSE,
                           intercept = FALSE,
                           lambda2 = 0, sigma = 1.0, method = "padmm")
    # toc()

    ii <- which(cvmodels$lambda== cvmodels$lambda.1se)
    B_init[, j] <- matrix(cvmodels$qraenet.fit$beta[,ii])
    A_init[, j] <- matrix(quantile(y[idx] - X[idx,]%*%B_init[,j], tau_K))
  }

  B_out <- B_init
  A_out <- A_init
  for (v in 1:T_outer) {
    # Construct pseudo responses # This matters
    # hv <- 3*(sqrt(s*log(N)/N) + s^{-1/2}*(c0*s^2*log(N)/n)^{(v)/2})
    # c0 <- 0.5
    hv <- (sqrt(s * log(N) / N) + s^{ -1 / 2 } * (c0 * s^2 * log(N) / n)^{ (v) / 2 })
    cat("hv = ", hv)
    # hv <- (sqrt(s * log(N) / N) + s^(-1 / 2 ) * (s^2 * log(N) / n)^(v/2))


    for (j in 1:m) {
      idx <- calN_j(n, j)
      E <- pracma::repmat(y[idx] - X[idx,]%*%B_out[,j], 1, K) - pracma::repmat(t(A_out[,j]), n, 1)
      fhat <- fh_vec(E, matrix(rep(hv, K), ncol = 1))
      cat(fhat, "\n\n")

      # cat(fhj, "\t")
      # yt[idx] <- X[idx,] %*% B_out[, j] - 1 / fhj * ((y[idx] < X[idx,] %*% B_out[, j]) - tau)
      ztmp <- (E<=0) - pracma::repmat(t(tau_K), n, 1)
      # cat((fhat), "\n\n")
      plot(dcauchy(qcauchy(tau_K)), col = 2)
      points(fhat)

      yt[idx] <- X[idx,]%*%B_out[,j] - 1/sum(fhat)*rowSums(ztmp)
      zt[idx,] <- pracma::repmat(t(A_out[,j]), n, 1) - ztmp/pracma::repmat(t(fhat), n, 1)
    }
    boxplot(yt)
    cat(sum(is.infinite(zt)), "\n")


    # lambda <- C0*(sqrt(log(N)/N) + sqrt(s*log(N)/n)*s^(- 1/2)*(c0*s^2*log(N)/n)^(v/2))
    # lambda_max <- min(max(abs(t(X)%*%(yt)/N)), lambda)

    # if(v == 1) lambda_max <- max(abs(t(X)%*%(yt)/N))
    # if(v > 1) lambda_max <- lambda + lambda/10


    N1 <- 50
    mu <-
      min(n / log(p), sqrt(N)) # Contrains by the relationship of n, p and s as indicated by the theorems.
    as <- rep(NA, N1 - 1)
    lambda_max <- max(abs(t(X) %*% (yt) / N))
    lambda_array <- exp(seq(log(1), log(1e-4), length.out = N1))
    lambda_array <- lambda_array[2:length(lambda_array)]
    lambda_array <- lambda_array * lambda_max
    bic_array <- rep(0, length(lambda_array))
    kk <- 0

    for (ilambda in 1:length(lambda_array)) {

      lambda <- lambda_array[ilambda]

      A_inner <- A_out
      B_inner <- B_out
      P_beta <- matrix(rep(0, p * m), nrow = p)
      P_alpha <- matrix(rep(0, K*m), nrow = K)
      for (t in 1:T_inner) {
        A_inner_old <- A_inner
        B_inner_old <- B_inner
        for (j in 1:m) {
          # loop over the network
          # cat(j)
          idx <- calN_j(n, j)
          neighbors_j <- neighbors(graph, j)
          P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner[, j] -
                                                                     B_inner[, neighbors_j])
          P_alpha[, j] <- P_alpha[, j] + tau_penalty_alpha * rowSums1(A_inner[, j] -
                                                                        A_inner[, neighbors_j])

          # tmp <- omega[j]*(
          #   rho[j]*B_inner_old[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner_old[,j] - yt[idx]) -
          #     P[,j] + tau_penalty*rowSums1(B_inner_old[,j] + B_inner_old[,neighbors_j])
          # )
          tmp <- omega[j] * (
            rho[j] * B_inner[, j] -
              1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner[, j] - yt[idx]) -
              P_beta[, j] + tau_penalty_beta * rowSums1(B_inner[, j] + B_inner[, neighbors_j])
          )
          B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])
          A_inner[, j] <- 1/(1 + 2*tau_penalty_alpha*m*length(neighbors_j))*(
            colSums(zt[idx,])/n - m*P_alpha[, j] + 2*tau_penalty_alpha*rowSums1(A_inner[,j] +
                                                                                  A_inner[,neighbors_j])
          )
        }
      }
      bic_array[ilambda] <- N * log(1 / N * sum(cqr_loss(X, y, B_inner[, 1, drop = FALSE],
                                                          A_inner[, 1, drop = F], tau_K))) +
        log(N) * sum(abs(B_inner[, 1]) > 0) # This is important


    }
    # as <- as[1:kk]
    # plot(as)
    # ii <- (1:length(as))[as == mod(as)]
    # ii <- ii[length(ii)]
    # lambda <- lambda_array[ii]

    # find the lambda such whose bic is the minimal
    ilambda <- which.min(bic_array)
    lambda <- lambda_array[ilambda]
    cat("Outer iteration = ", v, "lambda = ", lambda, "\n\n")
    B_inner <- B_out
    A_inner <- A_out
    P_beta <- matrix(rep(0, p * m), nrow = p)
    P_alpha <- matrix(rep(0, K * m), nrow = K)
    for (t in 1:T_inner) {
      B_inner_old <- B_inner
      A_inner_old <- A_inner
      for (j in 1:m) {
        # loop over the network
        # cat(j)
        idx <- calN_j(n, j)
        neighbors_j <- neighbors(graph, j)
        P_beta[, j] <- P_beta[, j] + tau_penalty_beta * rowSums1(B_inner[, j] - B_inner[, neighbors_j])
        P_alpha[, j] <- P_alpha[, j] + tau_penalty_alpha * rowSums1(A_inner[, j] - A_inner[, neighbors_j])

        # tmp <- omega[j]*(
        #   rho[j]*B_inner_old[,j] - 1/m/n*t(X[idx,])%*%(X[idx,]%*%B_inner_old[,j] - yt[idx]) -
        #     P[,j] + tau_penalty*rowSums1(B_inner_old[,j] + B_inner_old[,neighbors_j])
        # )
        tmp <- omega[j] * (
          rho[j] * B_inner[, j] -
            1 / m / n * t(X[idx,]) %*% (X[idx,] %*% B_inner[, j] - yt[idx]) -
            P_beta[, j] + tau_penalty_beta * rowSums1(B_inner[, j] + B_inner[, neighbors_j])
        )
        B_inner[, j] <- soft_thresholding(tmp, lambda * omega[j])
        A_inner[, j] <- 1/(1 + 2*tau_penalty_alpha*m*length(neighbors_j))*(
            colSums(zt[idx,])/n - m*P_alpha[, j] + 2*tau_penalty_alpha*rowSums1(A_inner[,j] +
                                                                                  A_inner[,neighbors_j])
          )
      }
      # cat("inner iteraion:", t, "\n\n")
      # cat(P_alpha, "\n\n")
      cat(norm(B_inner[, 3] - beta, "2")^2, "\t\n")
    }

    # plot(B_inner[,1])

    norm(B_init[, 3] - beta, "2")^2

    B_out <- B_inner
    A_out <- A_inner

    # cat(B_out[,1],"\n\n")

  }
  return(B_out)
}

# apply(B_out, 2, function(x) norm(matrix(x - beta)))
rowSums1 <- function(x) {
  if (is.null(dim(x))) {
    return(x)
  }
  return(rowSums(x))
}


calN_j <- function(n, j) {
  return((n * (j - 1) + 1):(n * j))
}

fh_vec <- function(E, h) {

  kernel <- function(x) {
    (-315 / 64 * x^6 + 735 / 64 * x^4 - 525 / 64 * x^2 + 105 / 64) * (abs(x) <= 1)
  }
  E <- E/pracma::repmat(t(h), nrow(E), 1)

  return(matrix(apply(kernel(E), 2, mean), ncol = 1)/h)
}

soft_thresholding <- function(x, t) {
  # pmax(x - t, 0) + pmax(-x - t, 0)
  pmax(x - t, 0) - pmax(-x - t, 0)
  # return(list(pmax(x - t, 0) - pmax(-x - t, 0),
  #             sign(x)*pmax((abs(x) - t), 0))
  # )
  # pmax(1 - t/x, 0)*x
  # sign(x)*pmax((abs(x) - t), 0)
}


check_loss <- function(x, tau) {
  # pmax(tau*x, 0) - pmax(-(1-tau)*x, 0)
  (abs(x) + (2 * tau - 1) * x) * 0.5
}
cqr_loss <- function (X, y, beta, alpha, tau) {
  s <- 0
  for (i in 1:length(tau)) {
    s <- s + check_loss(y - X%*%beta - alpha[i], tau[i])
  }
  return(s)
}


mod <- function(as) {
  return(unique(as)[which.max(purrr::map(unique(as), ~sum(as == .)))])
}

