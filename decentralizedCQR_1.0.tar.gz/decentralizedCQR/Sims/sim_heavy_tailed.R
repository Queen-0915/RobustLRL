# Simulation: Heavy_tailed
simulation_name <- "heavy_tailed"


# ============================================================== #
# LOAD LIBRARY
# ============================================================== #

library(rqPen)
library(FHDQR)
# library(FHDCQR)
library(cqrReg)
library(MASS)
library(pracma)
library(igraph) # for graph
library(tictoc)
library(hqreg)
library(glmnet)
library(ggplot2)
library(ggpubr)
# for parallel computing
library(doRNG)
library(foreach)
library(doFuture)
library(parallel)
library(decentralizedCQR)
library(xtable)


# ============================================================== #
# PREPROCESSING
# ============================================================== #

Platform <- Sys.info()['sysname']
fig_dir <- "Output/figs"
LOG_dir <- "Output/LOG"
createdir(fig_dir)
createdir(LOG_dir)

if (Platform == "Linux") {
  Nreps <- 100
  T_outer <- 20
  T_inner <- 50
  noise_type_arr <- c("Cauchy", "Normal", "T2")
  registerDoFuture()
  # use multiple workers to accelerate the time of replication, change
  # the number 123 to smaller number, e.g., 4 or 8 to accommodate your machine.
  plan(multisession, workers = 100)    ## on MS Windows
  # plan(multicore, workers = 123)     ## on Linux, Solaris, and macOS
}
if (Platform == "Darwin") {
  Nreps <- 8
  T_outer <- 10
  T_inner <- 50
  noise_type_arr <- c("Cauchy")
  registerDoFuture()
  plan(multisession, workers = 8)    ## on MS Windows
}


# ============================================================== #
# PARAMETERS
# ============================================================== #

m <- 10
# n <- 2e2
# N <- m * n
# p <- 1e2
s <- 10
rho <- .1
pc <- 0.3 # the connection probability
K <- 9 # the number of quantile levels
tau_K <- seq(1, K) / (K + 1)
lambda_factor <- 1e-4
nlambda <- 100L
lambda_max <- 20
quiet <- TRUE
c0 = 0.013
tau_penalty_factor <- 1 / 6
result <- vector(mode = "list", length = length(noise_type_arr))
n_p_arr <- list(c(100, 100), c(200, 100), c(200, 200))
# ============================================================== #
# MAIN ROUNTINE
# ============================================================== #

t_start <- tic()
for (inoise_type_arr in 1:length(noise_type_arr)) {
  noise_type <- noise_type_arr[inoise_type_arr]
  cat("The noise distribution is ", noise_type, "\n")

  set.seed(2022) # fix the seed
  r <- foreach(
    iNreps = 1:Nreps,
    .init = list(list(), # n = 100, p = 100
                 list(), # n = 200, p = 100
                 list() # n = 200, p = 100
    ),
    .combine = "comb"
  ) %dorng% {

    output_list <-
      vector(mode = "list", length = length(n_p_arr))
    for (in_p_arr in 1:length(n_p_arr)) {
      # Load the parameter
      n <- n_p_arr[[in_p_arr]][1]
      p <- n_p_arr[[in_p_arr]][[2]]
      N <- m * n
      cat("n = ", n, "p = ", p, "\n")
      
      # Generate data
      # fix seed
      # RNGkind("L'Ecuyer-CMRG")
      # .Random.seed <- attr(r, "rng")[[94]]
      data <-
        genData(
          N,
          m,
          p,
          s,
          pc,
          rho = .1,
          sigma2 = 1,
          type = noise_type,
          ishomo = TRUE,
          hetercase = 1
        )
      X <- data$X
      y <- data$y
      betaT <- data$betaT
      suppT <- which(abs(betaT)>0)
      graph <- data$graph
      adjacency_matrix <- as.matrix(as_adjacency_matrix(graph))
      
      # Estimate


      # Initial
      # CQR
      A_init_CQR <- matrix(rep(0, m * K), nrow = K)
      B_init_CQR <- matrix(rep(0, m * p), nrow = p)
      for (j in 1:m) {
        # get the index set for node j
        idx <- calN_j(n, j)

        cvmodels <- cv.qraenet(
          y = y[idx],
          x = X[idx,],
          tau = 0.5,
          intercept = FALSE,
          lambda2 = 0,
          sigma = 0.05,
          method = "padmm"
        )

        ii <- which(cvmodels$lambda == cvmodels$lambda.min)
        out <- matrix(cvmodels$qraenet.fit$beta[, ii])
        # coef.cutoff <- 1e-1
        # out[abs(out) <= coef.cutoff] <- 0
        coef.cutoff <- 5e-1
        out[abs(out) <= coef.cutoff] <- 0
        B_init_CQR[, j] <- out
        A_init_CQR[, j] <-
          matrix(quantile(y[idx] - X[idx,] %*% B_init_CQR[, j], tau_K))
      }

      # LS
      B_init_LS <- matrix(rep(0, m * p), nrow = p)
      for (j in 1:m) {
        # get the index set for node j
        idx <- calN_j(n, j)

        cvmodels <- cv.glmnet(
          y = y[idx],
          x = X[idx,],
          intercept = FALSE
        )

        ii <- which(cvmodels$lambda == cvmodels$lambda.min)
        out <- matrix(cvmodels$glmnet.fit$beta[, ii])
        B_init_LS[, j] <- out
      }

      
      out_beta_deSCQR <- decentralizedCQR_cpp(
        X = X,
        y = y,
        adjacency_matrix = adjacency_matrix,
        A_init = A_init_CQR,
        B_init = B_init_CQR,
        betaT = betaT,
        T_outer = T_outer,
        T_inner = T_inner,
        s = s,
        K = K,
        c0 = c0,
        tau_penalty_factor = tau_penalty_factor,
        lambda_factor = lambda_factor,
        nlambda = nlambda,
        lambda_max = lambda_max, # tunning parameter is very important; how to determine the upper bound
        quiet = quiet
      )
      error_deSCQR <- out_beta_deSCQR$history$errors_inner[length(out_beta_deSCQR$history$errors_inner)]
      F1_out_deSCQR <- apply(out_beta_deSCQR$B, 2, FUN = function(x) computeF1(which(abs(x)>0), suppT))
      precision_deSCQR <- mean(unlist(lapply(F1_out_deSCQR, `[[`, 2)))
      recall_deSCQR <- mean(unlist(lapply(F1_out_deSCQR, `[[`, 3)))
      
      out_beta_deLR <- deLR(X = X, y = y,
                              adjacency_matrix = adjacency_matrix,
                              B_init = B_init_LS,
                              betaT = betaT,
                              T_inner = T_inner*T_outer,
                              lambda_max = lambda_max,
                              quiet = F)
      error_deLR <- out_beta_deLR$history$errors_inner[length(out_beta_deLR$history$errors_inner)]
      F1_out_deLR <- apply(out_beta_deLR$B, 2, FUN = function(x) computeF1(which(abs(x)>0), suppT))
      precision_deLR <- mean(unlist(lapply(F1_out_deLR, `[[`, 2)))
      recall_deLR <- mean(unlist(lapply(F1_out_deLR, `[[`, 3)))
      
      output_list[[in_p_arr]] <-
        c(error_deLR, precision_deLR, recall_deLR, error_deSCQR, precision_deSCQR, recall_deSCQR)
    }
    output_list
  }
  result[[inoise_type_arr]] <- r

}
t_end <- toc(t_start)

# ============================================================== #
# OUPUT TABLE
# ============================================================== #
output_table <- vector(mode = "list", length = length(result))
for(inoise_type_arr in seq_along(noise_type_arr)) {
  noise_type <- noise_type_arr[inoise_type_arr]
  cat("The noise distribution is ", noise_type, "\n")
  r <- result[[inoise_type_arr]]
  output_table[[inoise_type_arr]] <- t(sapply(r, function(x) rowMeans(do.call(cbind, x), na.rm = T)))
}
xtable(do.call(rbind, output_table), digits = 4)

# ============================================================== #
# SAVE DATA
# ============================================================== #

save.image(file = paste0(
  LOG_dir,
  "/sim_",
  simulation_name,
  "_",
  format(Sys.time(), "%Y%m%d%H%M%S"),
  ".RData"
))