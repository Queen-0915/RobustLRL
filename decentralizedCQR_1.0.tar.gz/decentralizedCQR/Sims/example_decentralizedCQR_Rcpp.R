# Load library
library(rqPen)
library(FHDQR)
library(FHDCQR)
library(cqrReg)
library(MASS)
library(pracma)
library(igraph) # for graph
library(tictoc)
library(hqreg)
library(glmnet)
library(ggplot2)
library(ggpubr)
# parallel computing
library(doRNG)
library(foreach)
library(doFuture)
library(parallel)

source("../R/decentralizedCQR.R")
source("../R/utils.R")


# Preprocessing
Platform <- Sys.info()['sysname']
fig_dir <- "Output/figs"
LOG_dir <- "Output/LOG"
createdir(fig_dir)
createdir(LOG_dir)


# Parameters
m <- 10
n <- 2e2
N <- m * n
p <- 1e2
s <- 10
rho <- .1
pc <- 0.3 # the connection probability
K <- 9 # the number of quantile levels
tau_K <- seq(1, K) / (K + 1)
lambda_factor = 1e-4
nlambda = 100L
quiet = T
# c0 = 0.013
c0 = 0.1
tau_penalty_factor <- 1 / 6
# noise_type <- "Cauchy"
T_inner_arr <- c(20, 50, 100)

# Simulation: Iteratioins
noise_type_arr <- c("Cauchy", "Normal", "T2")
result <- vector(mode = "list", length = length(noise_type_arr))


inoise_type_arr <- 1
noise_type <- noise_type_arr[inoise_type_arr]
set.seed(20) # fix the seed
data <- genData(N, m, p, s, pc, rho = .1, sigma2 = 1, type = noise_type, ishomo = TRUE,
                hetercase = 1)
X <- data$X
y <- data$y
betaT <- data$betaT
graph <- data$graph
adjacency_matrix <- as.matrix(as_adjacency_matrix(graph))


# Initial


A_init <- matrix(rep(0, m * K), nrow = K)
B_init <- matrix(rep(0, m * p), nrow = p)
for (j in 1:m) {
  # get the index set for node j
  idx <- calN_j(n, j)

  cvmodels <- cv.qraenet(y = y[idx], x = X[idx,], tau = 0.5,
                         intercept = FALSE,
                         lambda2 = 0, sigma = 0.05, method = "padmm")
  
  ii <- which(cvmodels$lambda == cvmodels$lambda.min)
  out <- matrix(cvmodels$qraenet.fit$beta[, ii])
  coef.cutoff <- 5e-1
  out[abs(out)<=coef.cutoff] <- 0
  B_init[, j] <- out
  A_init[, j] <- matrix(quantile(y[idx] - X[idx,] %*% B_init[, j], tau_K))
  
  
}
error_init <-  sqrt(mean(colSums((B_init - repmat(betaT, 1, m))^2)))


tau_penalty_factor <- 1
c0 <- 0.013
nlambda <- 100
tic()
out_100 <- decentralizedCQR_cpp(X = X, y = y,  adjacency_matrix = adjacency_matrix , 
                               A_init = A_init, B_init = B_init, betaT = betaT, T_outer = 20, T_inner = 60,  
                               s = s, K = K, c0 = c0, tau_penalty_factor = 0.5, nlambda = nlambda, quiet = F)
toc()

tic()
out_50 <- decentralizedCQR_cpp(X = X, y = y,  adjacency_matrix = adjacency_matrix , 
                            A_init = A_init, B_init = B_init, betaT = betaT, T_outer = 20, T_inner = 40,  
                            s = s, K = K, c0 = c0, tau_penalty_factor = 0.5, nlambda = nlambda, quiet = F)
toc()

tic()
out_20 <- decentralizedCQR_cpp(X = X, y = y,  adjacency_matrix = adjacency_matrix , 
                               A_init = A_init, B_init = B_init, betaT = betaT, T_outer = 20, T_inner = 20,  
                               s = s, K = K, c0 = c0, tau_penalty_factor = .5, nlambda = nlambda,  quiet = F)
toc()

# plot( out_100$history$errors_outer, type = "b", ylim = c(0.2, 0.6))
# lines(out_50$history$errors_outer, type = "b", lty = 2, pch = 2)
# lines(out_20$history$errors_outer, type = "b", lty = 3, pch = 3)
plot(c(error_init, out_100$history$errors_outer), type = "b")
lines(c(error_init, out_50$history$errors_outer), type = "b", lty = 2, pch = 2)
lines(c(error_init, out_20$history$errors_outer), type = "b", lty = 3, pch = 3)
legend(15, 0.62, c("T_inner = 60", "T_inner = 40", "T_inner = 20"), lty = c(1,2,3), pch = c(1,2,3), bg = "lightblue")

plot(c(error_init, out_50$history$errors_inner), type = "b")
lines(c(error_init, out_20$history$errors_inner), type = "b", lty = 2, pch = 2)
