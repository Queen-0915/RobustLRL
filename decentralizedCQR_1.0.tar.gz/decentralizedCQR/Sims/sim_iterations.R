# Simulation: Iteratioins
simulation_name <- "iterations"


# ============================================================== #
# LOAD LIBRARY
# ============================================================== #

library(rqPen)
library(FHDQR)
# library(FHDCQR)
library(cqrReg)
library(MASS)
library(pracma)
library(igraph) # for graph
library(tictoc)
library(hqreg)
library(glmnet)
library(ggplot2)
library(ggpubr)
# for parallel computing
library(doRNG)
library(foreach)
library(doFuture)
library(parallel)
library(decentralizedCQR)






# ============================================================== #
# PREPROCESSING
# ============================================================== #

Platform <- Sys.info()['sysname']
fig_dir <- "Output/figs"
LOG_dir <- "Output/LOG"
createdir(fig_dir)
createdir(LOG_dir)

if (Platform == "Linux") {
  Nreps <- 100
  T_outer <- 50
  registerDoFuture()
  # use multiple workers to accelerate the time of replication, change
  # the number 123 to smaller number, e.g., 4 or 8 to accommodate your machine.
  plan(multisession, workers = 100)    ## on MS Windows
  # plan(multicore, workers = 123)     ## on Linux, Solaris, and macOS
}
if (Platform == "Darwin") {
  Nreps <- 8
  T_outer <- 10
  registerDoFuture()
  plan(multisession, workers = 8)    ## on MS Windows
}




# ============================================================== #
# PARAMETERS
# ============================================================== #

m <- 10
n <- 2e2
N <- m * n
p <- 1e2
s <- 10
rho <- .1
pc <- 0.3 # the connection probability
K <- 9 # the number of quantile levels
# K <- 5 # the number of quantile levels
tau_K <- seq(1, K) / (K + 1)
lambda_factor <-  1e-3
# nlambda <- 200L
nlambda <- 100L
quiet <- F
c0 = 0.013
# c0 <- 0.1
# tau_penalty_factor <- 1 / 6
tau_penalty_factor <- 1
T_inner_arr <- c(20, 50, 100)
noise_type_arr <- c("Cauchy", "Normal", "T2")
result <- vector(mode = "list", length = length(noise_type_arr))


# ============================================================== #
# MAIN ROUNTINE
# ============================================================== #

t_start <- tic()
for (inoise_type_arr in 1:length(noise_type_arr)) {
  noise_type <- noise_type_arr[inoise_type_arr]
  cat("The noise distribution is ", noise_type)

  set.seed(2022) # fix the seed
  r <- foreach(
    iNreps = 1:Nreps,
    .init = list(list(), list(), list()),
    .combine = "comb"
  ) %dorng% {
    # fix seed
    # RNGkind("L'Ecuyer-CMRG")
    # .Random.seed <- attr(r, "rng")[[46]]
    # RNGkind("L'Ecuyer-CMRG")
    # .Random.seed <- attr(r, "rng")[[86]]
    # RNGkind("L'Ecuyer-CMRG")
    # .Random.seed <- attr(r, "rng")[[1]]
    data <-
      genData(
        N,
        m,
        p,
        s,
        pc,
        rho = .1,
        sigma2 = 1,
        type = noise_type,
        ishomo = TRUE,
        hetercase = 1
      )
    X <- data$X
    y <- data$y
    betaT <- data$betaT
    graph <- data$graph
    adjacency_matrix <- as.matrix(as_adjacency_matrix(graph))
    
    
    # Initial
    
    
    A_init <- matrix(rep(0, m * K), nrow = K)
    B_init <- matrix(rep(0, m * p), nrow = p)
    for (j in 1:m) {
      # get the index set for node j
      idx <- calN_j(n, j)
      
      cvmodels <- cv.qraenet(
        y = y[idx],
        x = X[idx,],
        tau = 0.5,
        intercept = FALSE,
        lambda2 = 0,
        sigma = 0.05,
        method = "padmm"
      )
      
      ii <- which(cvmodels$lambda == cvmodels$lambda.min)
      out <- matrix(cvmodels$qraenet.fit$beta[, ii])
      # coef.cutoff <- 1e-1
      # out[abs(out) <= coef.cutoff] <- 0
      coef.cutoff <- 5e-1
      out[abs(out) <= coef.cutoff] <- 0
      B_init[, j] <- out
      A_init[, j] <-
        matrix(quantile(y[idx] - X[idx,] %*% B_init[, j], tau_K))
      
      
    }
    error_init <-
      sqrt(mean(colSums((
        B_init - repmat(betaT, 1, m)
      ) ^ 2)))
    
    output_list <-
      vector(mode = "list", length = length(T_inner_arr))
    for (iT_inner_arr in 1:length(T_inner_arr)) {
      # Estimate
      T_inner <- T_inner_arr[iT_inner_arr]
      
      out_beta_deSCQR <- decentralizedCQR_cpp(
        X = X,
        y = y,
        adjacency_matrix = adjacency_matrix,
        A_init = A_init,
        B_init = B_init,
        betaT = betaT,
        T_outer = T_outer,
        T_inner = T_inner,
        s = s,
        K = K,
        c0 = c0,
        tau_penalty_factor = tau_penalty_factor,
        lambda_factor = lambda_factor,
        nlambda = nlambda,
        lambda_max = .5, # tunning parameter is very important; how to determine the upper bound
        quiet = quiet
      )
      # out_beta_deSCQR <- decentralizedCQR(X, y, graph, betaT, s, K = K, T_outer = T_outer, T_inner = T_inner,
      #                                     c0 = c0, tau_penalty_factor = tau_penalty_factor,
      #                                     nlambda = nlambda, lambda_factor = lambda_factor,
      #                                     quiet = quiet)
      
      output_list[[iT_inner_arr]] <-
        c(error_init, out_beta_deSCQR$history$errors_outer)
    }
    output_list
  }
  result[[inoise_type_arr]] <- r
  
}
t_end <- toc(t_start)




# ============================================================== #
# PLOT
# ============================================================== #

for (inoise_type_arr in 1:length(noise_type_arr)) {
  noise_type <- noise_type_arr[inoise_type_arr]
  cat("The noise distribution is ", noise_type, "\n")
  
  r <- result[[inoise_type_arr]]
  
  
  pdf(paste0(fig_dir, "/fig_iterations_", noise_type, ".pdf"))
  
  op <- par(no.readonly = TRUE)
  fontsize <- 12
  type <- "l"
  lwd <- 3
  par(
    font = fontsize,
    font.axis = fontsize,
    font.lab = fontsize,
    font.main = fontsize,
    font.sub = fontsize,
    cex = 1.5,
    mar = c(2,2,1,1)
  )
  plot(
    rowMeans(do.call(cbind, r[[1]]), na.rm = T),
    type = type,
    ylim = c(
      min(
        rowMeans(do.call(cbind, r[[1]])),
        rowMeans(do.call(cbind, r[[2]])),
        rowMeans(do.call(cbind, r[[3]])),
        na.rm = T
      ),
      max(
        rowMeans(do.call(cbind, r[[1]])),
        rowMeans(do.call(cbind, r[[2]])),
        rowMeans(do.call(cbind, r[[3]])),
        na.rm = T
      )
    ),
    lwd = lwd,
    xlab = "",
    ylab = ""
  )
  lines(
    rowMeans(do.call(cbind, r[[2]]), na.rm = T),
    type = type,
    pch = 2,
    col = 2,
    lty = 2,
    lwd = lwd
  )
  lines(
    rowMeans(do.call(cbind, r[[3]]), na.rm = T),
    type = type,
    pch = 3,
    col = 3,
    lty = 3,
    lwd = lwd
  )
  # legend(
  #   x = "topright",
  #   c("20", "50", "100"),
  #   lty = c(1, 2, 3),
  #   pch = c(1, 2, 3),
  #   col = c(1, 2, 3),
  #   lwd = rep(lwd, 3)
  # )
  
  par(op)
  
  dev.off()
}




# ============================================================== #
# SAVE DATA
# ============================================================== #

save.image(file = paste0(
  LOG_dir,
  "/sim_",
  simulation_name,
  "_",
  format(Sys.time(), "%Y%m%d%H%M%S"),
  ".RData"
))