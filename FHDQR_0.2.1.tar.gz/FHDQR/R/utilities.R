#' @importFrom stats approx
#' @importFrom methods new
#' @import Matrix
#' @importFrom graphics segments
#'
#-----------------------------------------------------------------------------
# THESE FUNCTIONS ARE MINOR MODIFICATIONS FROM THE GLMNET PACKAGE:
#   JEROME FRIEDMAN, TREVOR HASTIE, ROBERT TIBSHIRANI (2010).
#   REGULARIZATION PATHS FOR GENERALIZED LINEAR MODELS VIA COORDINATE DESCENT.
#   JOURNAL OF STATISTICAL SOFTWARE, 33(1), 1-22.
#   URL HTTP://WWW.JSTATSOFT.ORG/V33/I01/.
# THE REASON SOME OF THEM ARE COPIED OVER HERE IS BECAUSE THEY ARE INTERNAL
# FUNCTIONS AND HENCE ARE NOT EXPORTED INTO THE GLOBAL ENVIRONMENT.
# THE ORIGINAL COMMENTS AND HEADER ARE PRESERVED.
#-----------------------------------------------------------------------------

err <- function(n, maxit, vmax) {
  if (n == 0)  msg <- ""
  if (n > 0) {
    if (n == 88888)
      msg <- "Fail to find the largest eigenvalue of the Gram matrix"
    if (n < 7777)
      msg <- "Memory allocation error"
    if (n == 7777)
      msg <- "All used predictors have zero variance"
    if (n == 10000)
      msg <- "All penalty factors are <= 0"
    n <- 1
    msg <- paste("In qraenet fortran code:", msg)
  }
  if (n < 0) {
    if (n > -10000)
      msg <- paste("Convergence for ", -n,
                   "th lambda value not reached after maxit=",
                   maxit,
                   " iterations; Solutions for larger lambdas returned",
                   sep = "")
    if (n < -10000)
      msg <- paste("Number of nonzero coefficients along the path exceeds vmax=",
                   vmax, " at ", -n-10000,
                   "th lambda value; solutions for larger lambdas returned",
                   sep = "")
    n <- -1
    msg <- paste("From qraenet fortran code:", msg)
  }
  list(n = n, msg = msg)
}


error.bars <- function(x, upper, lower, width = 0.02, ...) {
  xlim <- range(x)
  barw <- diff(xlim) * width
  segments(x, upper, x, lower, ...)
  segments(x - barw, upper, x + barw, upper, ...)
  segments(x - barw, lower, x + barw, lower, ...)
  range(upper, lower)
}


getmin <- function(lambda, cvm, cvsd) {
  cvmin <- min(cvm)
  idmin <- cvm <= cvmin
  lambda.min <- max(lambda[idmin])
  idmin <- match(lambda.min, lambda)
  semin <- (cvm + cvsd)[idmin]
  idmin <- cvm <= semin
  lambda.1se <- max(lambda[idmin])
  list(lambda.min = lambda.min, lambda.1se = lambda.1se)
}


getoutput <- function(fit, maxit, vmax, nvars, vnames, only_lambda) {
  if (only_lambda) {
    nalam <- fit$nalam
    lam <- fit$alam[seq(nalam)]
    stepnames <- paste("s", seq(nalam) - 1, sep = "")
    errmsg <- err(fit$jerr, maxit, vmax)
    switch(paste(errmsg$n), `1` = stop(errmsg$msg, call. = FALSE),
           `-1` = print(errmsg$msg, call. = FALSE))
    dd <- c(nvars, nalam)
    beta <- zeromat(nvars, nalam, vnames, stepnames)
    df <- rep(0L, nalam)
    b0 <- c(fit$b0[1], rep(0.0, nalam-1))
  } else {
    nalam <- fit$nalam
    nbeta <- fit$nbeta[seq(nalam)]
    nbetamax <- max(nbeta)
    lam <- fit$alam[seq(nalam)]
    stepnames <- paste("s", seq(nalam) - 1, sep = "")
    errmsg <- err(fit$jerr, maxit, vmax)
    switch(paste(errmsg$n), `1` = stop(errmsg$msg, call. = FALSE),
           `-1` = print(errmsg$msg, call. = FALSE))
    dd <- c(nvars, nalam)
    if (nbetamax > 0) {
      beta <- matrix(fit$beta[seq(vmax * nalam)],
                     vmax, nalam)[seq(nbetamax), , drop = FALSE]
      df <- apply(abs(beta) > 0, 2, sum)
      ja <- fit$ibeta[seq(nbetamax)]
      oja <- order(ja)
      ja <- rep(ja[oja], nalam)
      ibeta <- cumsum(c(1, rep(nbetamax, nalam)))
      beta <- new("dgCMatrix", Dim = dd,
                  Dimnames = list(vnames, stepnames),
                  x = as.vector(beta[oja, ]),
                  p = as.integer(ibeta - 1),
                  i = as.integer(ja - 1))
    } else {
      beta <- zeromat(nvars, nalam, vnames, stepnames)
      df <- rep(0L, nalam)
    }
    b0 <- fit$b0
    if (!is.null(b0)) {
      b0 <- b0[seq(nalam)]
      names(b0) <- stepnames
    }
  }
  list(b0 = b0, beta = beta, df = df, dim = dd, lambda = lam)
}


lambda.interp <- function(lambda, s) {
  # LAMBDA IS THE INDEX SEQUENCE THAT IS PRODUCED BY THE MODEL;
  # S IS THE NEW VECTOR AT WHICH EVALUATIONS ARE REQUIRED.
  # THE VALUE IS A VECTOR OF LEFT AND RIGHT INDICES, AND A VECTOR OF FRACTIONS.
  # THE NEW VALUES ARE INTERPOLATED BEWTEEN THE TWO USING THE FRACTION
  # NOTE: LAMBDA DECREASES. YOU TAKE: SFRAC*LEFT+(1-SFRAC)*RIGHT
  if (length(lambda) == 1) {
    nums <- length(s)
    left <- rep(1, nums)
    right <- left
    sfrac <- rep(1, nums)
  } else {
    s[s > max(lambda)] <- max(lambda)
    s[s < min(lambda)] <- min(lambda)
    k <- length(lambda)
    sfrac <- (lambda[1] - s)/(lambda[1] - lambda[k])
    lambda <- (lambda[1] - lambda)/(lambda[1] - lambda[k])
    coord <- approx(lambda, seq(lambda), sfrac)$y
    left <- floor(coord)
    right <- ceiling(coord)
    sfrac <- (sfrac - lambda[right])/(lambda[left] - lambda[right])
    sfrac[left == right] <- 1
  }
  list(left = left, right = right, frac = sfrac)
}


lamfix <- function(lam) {
  llam <- log(lam)
  lam[1] <- exp(2 * llam[2] - llam[3])
  lam
}


nonzero <- function(beta, bystep = FALSE) {
  ns <- ncol(beta)
  # BETA SHOULD BE IN 'DGCMATRIX' FORMAT
  if (nrow(beta) == 1) {
    if (bystep) {
      apply(beta, 2, function(x) if (abs(x) > 0) 1 else NULL)
    } else {
      if (any(abs(beta) > 0)) 1 else NULL
    }
  } else {
    beta <- t(beta)
    which <- diff(beta@p)
    which <- seq(which)[which > 0]
    if (bystep) {
      nzel <- function(x, which) if (any(x)) which[x] else NULL
      beta <- abs(as.matrix(beta[, which])) > 0
      if (ns == 1) {
        apply(beta, 2, nzel, which)
      } else apply(beta, 1, nzel, which)
    } else which
  }
}


zeromat <- function(nvars, nalam, vnames, stepnames) {
  ca <- rep(0, nalam)
  ia <- seq(nalam + 1)
  ja <- rep(1, nalam)
  dd <- c(nvars, nalam)
  new("dgCMatrix", Dim = dd, Dimnames = list(vnames, stepnames),
      x = as.vector(ca), p = as.integer(ia - 1), i = as.integer(ja - 1))
}


## check loss
chkls <- function(r, tau) {
  0.5 * (abs(r) + (2.0 * tau - 1.0) * r)
}
