#' @export
predict.qraenet <- function(object, newx, s = NULL,
                            type = "response", ...)
  NextMethod("predict")
