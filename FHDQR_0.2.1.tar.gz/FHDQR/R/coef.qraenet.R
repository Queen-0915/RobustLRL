#' @export
coef.qraenet <- function(object, s = NULL,
                         type = c("coefficients",  "nonzero"), ...)
  NextMethod("coef")
