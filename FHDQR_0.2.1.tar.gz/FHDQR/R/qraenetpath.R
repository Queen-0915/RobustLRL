#' @useDynLib FHDQR
#'
#-----------------------------------------------------------------------------
qraenetpath <- function(x, y, nlam, flmin, ulam, isd, intr, eps, dfmax,
                        vmax, jd, pf, pf2, maxit, lam2, tau, nobs, nvars,
                        vnames, sigma, onlylam, tol, method, gamma,
                        verbose) {
  #-----------------------------------------------------------------------------
  # DATA SETUP
  storage.mode(y) <- "double"
  storage.mode(x) <- "double"
  if (tau <= 0 || tau >= 1) stop("'tau' must be in (0,1)")
  tau <- as.double(tau)
  #-----------------------------------------------------------------------------
  # CALL FORTRAN CORE
  if (method == "scdadmm") {
    fit <- .Fortran("QRAENET", tau = tau, lambda2 = lam2, nobs = nobs,
                    nvars = nvars, x = x, y = y, jd = jd, pf = pf,
                    pf2 = pf2, dfmax = dfmax, vmax = vmax, nlam = nlam,
                    flmin = flmin, ulam = ulam, eps = eps, isd = isd,
                    intr = intr, maxit = maxit, nalam = integer(1),
                    b0 = double(nlam), beta = double(vmax * nlam),
                    ibeta = integer(vmax), nbeta = integer(nlam),
                    alam = double(nlam), npass = integer(1),
                    jerr = integer(1), sigma = sigma,
                    onlylam = as.integer(onlylam), tol = tol,
                    verbose = as.integer(verbose),
                    PACKAGE = "FHDQR")
  } else if (method == "padmm") {
    fit <- .Fortran("QRAENETV", tau = tau, lambda2 = lam2, nobs = nobs,
                    nvars = nvars, x = x, y = y, jd = jd, pf = pf,
                    pf2 = pf2, dfmax = dfmax, vmax = vmax, nlam = nlam,
                    flmin = flmin, ulam = ulam, eps = eps, isd = isd,
                    intr = intr, maxit = maxit, nalam = integer(1),
                    b0 = double(nlam), beta = double(vmax * nlam),
                    ibeta = integer(vmax), nbeta = integer(nlam),
                    alam = double(nlam), npass = integer(1),
                    jerr = integer(1), sigma = sigma, gamma = gamma,
                    onlylam = as.integer(onlylam), lmax = double(1),
                    verbose = as.integer(verbose),
                    PACKAGE = "FHDQR")
  }
  #-----------------------------------------------------------------------------
  # OUTPUT
  outlist <- getoutput(fit, maxit, vmax, nvars, vnames, onlylam)
  outlist <- if (method == "scdadmm")
    c(outlist, list(npasses = fit$npass, jerr = fit$jerr))
  else if (method == "padmm")
    c(outlist, list(npasses = fit$npass, jerr = fit$jerr,
                    sigma = fit$sigma, lmax = fit$lmax,
                    eps = fit$eps))
  class(outlist) <- c("qraenetpath")
  outlist
}
