#' Cross-validation for the adaptive elastic net penalized
#' quantile regression
#'
#' Does k-fold cross-validation for the adaptive elastic net
#' penalized quantile regression, produces a plot, and returns
#' cross-validated results for best lambda.
#'
#' @param x The \code{x} matrix as in \code{\link{qraenet}}.
#' @param y Response variable \code{y} as in \code{\link{qraenet}}.
#' @param lambda Optional user-supplied lambda sequence;
#'   default is \code{NULL}, for which \code{\link{qraenet}}
#'   chooses its own sequence.
#' @param nfolds Number of folds. Default value is \code{5L}.
#'   Although \code{nfolds} can be as large as the sample
#'   size (the leave-one-out CV), it is not recommended
#'   for large data sets. Smallest value allowed is \code{3L}.
#' @param foldid An optional vector of values between 1 and
#'   \code{nfolds}, identifying which fold each observation
#'   is in. If supplied, \code{nfolds} will be supressed.
#' @param pred.loss Loss function used to calculate the
#'   cross-validation error. The only option now is
#'   "\code{loss}", which is the check loss.
#' @param tau The quantile level \code{tau} used in the check error loss.
#' @param \dots Other arguments that can be passed to \code{qraenet}.
#'
#' @export
#'
#' @details
#' The function runs \code{\link{qraenet}} (\code{nfolds}+1) times;
#' the first is fitted to get the \code{lambda} sequence, and the
#' remainder are used to compute the fit with each of the folds
#' removed. The average error and standard deviation over the
#' folds are computed.
#'
#' @return
#' An object of class \code{cv.qraenet} is returned,
#' which is a list with the ingredients of the cross-validated fit.
#'  \item{lambda}{the values of \code{lambda} used in the fits.}
#'  \item{cvm}{the mean cross-validated error - a vector of length
#'             \code{length(lambda)}.}
#'  \item{cvsd}{estimate of standard error of \code{cvm}.}
#'  \item{cvupper}{upper curve = \code{cvm+cvsd}.}
#'  \item{cvlower}{lower curve = \code{cvm-cvsd}.}
#'  \item{nzero}{number of non-zero coefficients at each \code{lambda}.}
#'  \item{name}{a text string indicating type of measure
#'              (for plotting purposes).}
#'  \item{qraenet.fit}{a fitted \code{\link{qraenet}} object for
#'                     the full data.}
#'  \item{lambda.min}{The optimal value of \code{lambda} that gives
#'                    minimum cross validation error \code{cvm}.}
#'  \item{lambda.1se}{The largest value of \code{lambda} such that
#'                    error is within 1 standard error of the minimum.}
#'
#' @author
#' Yuwen Gu <guxxx192@umn.edu>,
#' Hui Zou <zouxx019@umn.edu>
#'
#' Maintainer: Yuwen Gu <guxxx192@umn.edu>
#'
#' @references Gu, Y., Fan, J., Kong, L., Ma, S. and Zou, H., "ADMM for
#'   high-dimensional sparse penalized quantile regression". To appear in
#'   \emph{Technometrics}.
#'
#' @seealso \code{\link{qraenet}}
#'
#' @examples
#' set.seed(1)
#' n <- 100
#' p <- 400
#' x <- matrix(rnorm(n*p), n, p)
#' y <- rnorm(n)
#' tau <- 0.70
#' lambda2 <- 1.0
#' cvmodels <- cv.qraenet(y = y, x = x, tau = tau,
#'                        standardize = FALSE,
#'                        intercept = FALSE,
#'                        lambda2 = lambda2)
#'
#' @keywords models regression


#' @importFrom parallel mclapply
cv.qraenet <- function(x, y, lambda = NULL, pred.loss = "loss",
                       nfolds = 5L, foldid, tau = 0.5,
                       parallel = FALSE,
                       mc.cores = getOption("mc.cores", 2L),
                       ...) {
    pred.loss <- match.arg(pred.loss)
    N <- nrow(x)
    ## Fit the model once to get model parameters
    y <- drop(y)
    qraenet.object <- qraenet(x, y, lambda = lambda, tau = tau, ...)
    lambda <- qraenet.object$lambda
    # predict -> coef
    nz <- sapply(coef(qraenet.object, type = "nonzero"), length)
    if (missing(foldid)) {
      foldid <- sample(rep(seq(nfolds), length = N))
    } else nfolds <- max(foldid)
    if (nfolds < 3L)
      stop("nfolds must be at least 3; nfolds = 10 recommended")
    ## Now fit the nfold models and store them
    fit_models <- function(index) {
      whichfold <- foldid == index
      y_sub <- y[!whichfold]
      qraenet(x = x[!whichfold, , drop = FALSE],
              y = y_sub, lambda = lambda, tau = tau, ...)
    }
    if (parallel) {
      outlist <- mclapply(seq(nfolds), fit_models,
                          mc.cores = mc.cores)
    } else {
      outlist <- lapply(seq(nfolds), fit_models)
    }
    ## What to do depends on the pred.loss and the model fit
    fun <- paste("cv", class(qraenet.object)[[2]], sep = ".")
    cvstuff <- do.call(fun, list(outlist, lambda, x, y,
                                 foldid, pred.loss, tau))
    cvm <- cvstuff$cvm
    cvsd <- cvstuff$cvsd
    cvname <- cvstuff$name
    out <- list(lambda = lambda, cvm = cvm, cvsd = cvsd,
                cvupper = cvm + cvsd, cvlower = cvm - cvsd,
                nzero = nz, name = cvname,
                qraenet.fit = qraenet.object)
    lamin <- getmin(lambda, cvm, cvsd)
    obj <- c(out, as.list(lamin))
    class(obj) <- "cv.qraenet"
    obj
}
