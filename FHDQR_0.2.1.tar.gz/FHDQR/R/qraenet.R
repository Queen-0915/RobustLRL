#' Adaptive elastic net penalized quantile regression via ADMM
#'
#' Fits regularization paths for the (adaptive) lasso or (adaptive)
#' elastic net penalized quantile regression at a sequence of L1
#' regularization parameters via the ADMM or proximal ADMM algorithm.
#'
#' @param x Matrix of predictors, of dimension (nobs * nvars);
#'   each row is an observation.
#' @param y Response variable.
#' @param nlambda The number of \code{lambda} values (default is 100).
#' @param method A character string specifying the algorithm to use.
#'   Available options are \code{scdadmm} and \code{padmm} standing for
#'   the sparse coordinate descent ADMM and proximal ADMM respectively.
#' @param lambda.factor The factor for getting the minimal value
#'   in the \code{lambda} sequence, where
#'   \code{min(lambda)} = \code{lambda.factor} * \code{max(lambda)}
#'   and \code{max(lambda)} is the smallest value of \code{lambda}
#'   for which all coefficients (except the intercept when it is present)
#'   are penalized to zero. The default depends on the relationship
#'   between \eqn{n} (the number of rows in the design matrix) and
#'   \eqn{p} (the number of predictors). If \eqn{n < p}, it defaults to
#'   \code{0.05}. If \eqn{n > p}, the default is \code{0.001},
#'   closer to zero.  A very small value of \code{lambda.factor} will
#'   lead to a saturated fit. The argument takes no effect if there is a
#'   user-supplied \code{lambda} sequence.
#' @param lambda A user-supplied \code{lambda} sequence. Typically,
#'   by leaving this option unspecified, users can have the program
#'   compute its own \code{lambda} sequence based on \code{nlambda}
#'   and \code{lambda.factor}. It is better to supply, if necessary,
#'   a decreasing sequence of \code{lambda} values than a single
#'   (small) value. The program will ensure that the user-supplied
#'   \code{lambda} sequence is sorted in decreasing order before
#'   fitting the model to take advanage of the warm-start technique.
#' @param lambda2 Regularization parameter \code{lambda2} for the
#'   quadratic penalty of the coefficients. Unlike \code{lambda},
#'   only one value of \code{lambda2} is used for each fitting process.
#' @param pf L1 penalty factor of length \eqn{p} used for the adaptive
#'   LASSO or adaptive elastic net. Separate L1 penalty weights can be
#'   applied to each coefficient to allow different L1 shrinkage.
#'   Can be 0 for some variables (but not all), which imposes no
#'   shrinkage, and results in that variable always being included
#'   in the model. Default is 1 for all variables (and implicitly
#'   infinity for variables in the \code{exclude} list).
#' @param pf2 L2 penalty factor of length \eqn{p} used for adaptive
#'   elastic net. Separate L2 penalty weights can be applied to
#'   each coefficient to allow different L2 shrinkage.
#'   Can be 0 for some variables, which imposes no shrinkage.
#'   Default is 1 for all variables.
#' @param exclude Indices of variables to be excluded from the model.
#'   Default is none. Equivalent to an infinite penalty factor.
#' @param dfmax The maximum number of variables allowed in the model.
#'   Useful for very large \eqn{p} when a partial path is desired.
#'   Default is \eqn{p+1}.
#' @param vmax The maximum number of coefficients allowed ever
#'   to be nonzero along the solution path. For example, once
#'   \eqn{\beta} enters the model, no matter how many times it
#'   exits or re-enters the model through the path, it will be
#'   counted only once. Default is \code{min(dfmax*1.2, p)}.
#' @param standardize Logical flag for variable standardization,
#'   prior to fitting the model sequence. The coefficients are
#'   always returned to the original scale. Default is \code{TRUE}.
#' @param intercept Should the intercept be fitted (default
#'   \code{TRUE}) or set to zero (\code{FALSE})?
#' @param eps Convergence thresholds for the ADMM algorithm.
#'   A numeric vector of length 2. The first component is the
#'   absolute tolerance and the second component is the
#'   relative tolerance. The two together control the primal
#'   and dual residuals of the ADMM algorithm.
#'   Default value is \code{c(1e-3,1e-3)}.
#' @param maxit Maximum number of iterations allowed in the ADMM
#'   algorithm at fixed lambda values. Default is \code{100000L}.
#'   If the algorithm does not converge, consider increasing
#'   \code{maxit}.
#' @param tau The quantile level \eqn{\tau}. The value must be
#'   in (0,1). Default is 0.5.
#' @param sigma Penalty parameter appearing in the quadratic term
#'   of the augmented Lagrangian function. Must be positive.
#'   See details for discussions on how to choose \code{sigma}.
#' @param tol Tolerance level in the coordinate descent algorithm
#'   for updating beta in the classical ADMM. No effect for the
#'   proximal ADMM algorithm. Default is 1e-7.
#' @param onlylam Logical flag indicating if the algorithm only
#'   needs to compute the lambda sequence. If \code{TRUE}, the
#'   coefficients \code{beta} and \code{b0} will not be computed
#'   and only the \code{lambda} sequence is effectively calculated.
#'   Otherwise, the coefficients as well as the \code{lambda}
#'   sequence will be computed. Default is \code{FALSE}.
#' @param verbose Whether or not to print runing messages? Default
#'   is FALSE.
#'
#' @details
#' Note that the objective function in the penalized quantile
#' regression is
#'   \deqn{1'\rho_{\tau}(y-X\beta))/N + \lambda_1\cdot|pf_1\circ\beta|_1 +
#'     0.5*\lambda_2\cdot|\sqrt{pf_2}\circ\beta|^2,}{
#'     1'\rho[\tau](y-X\beta))/N + \lambda[1]*|pf1•\beta|[1]
#'     + 0.5*\lambda_{2}*|\sqrtpf2•\beta|^2,}
#'   where \eqn{\rho_{\tau}}{\rho_{\tau}} the quantile or check loss
#'   and the penalty is a combination of weighted L1 and L2 terms and
#'   \eqn{\circ}{•} denotes the Hadmamard product.
#'
#' In theory, the (proximal) ADMM algorithm converges regardless
#' of the value the penalty parameter (which appears in the
#' quadratic term of the augmented Lagrangian function) takes
#' as long as it is positive. However, empirical evidence
#' shows that this penalty parameter significantly impacts the
#' convergence speed and accuracy of the ADMM algorithm.
#' In our implementation for the proximal ADMM algorithm,
#' we take \code{sigma} to be a scaled version of this penalty
#' parameter and the scale is given by the largest eigenvalue
#' \code{lmax} of the gram matrix \code{x}'\code{x}. Specifically,
#' we have \code{sigma} = (penalty parameter)*\code{lmax}.
#' Default is 0.05. For the classicial ADMM algorithm, no
#' scaling is applied to the penalty parameter and the default
#' is also 0.05.
#'
#' For faster computation, if the algorithm is not converging or
#' running slow, consider increasing \code{eps}, increasing
#' \code{sigma}, decreasing \code{nlambda}, or increasing
#' \code{lambda.factor} before increasing \code{maxit}.
#'
#' @return
#' An object with S3 class \code{qraenet} consisting of
#'   \item{call}{the call that produced this object}
#'   \item{b0}{intercept sequence of length \code{length(lambda)}}
#'   \item{beta}{a \code{p*length(lambda)} matrix of coefficients,
#'               stored as a sparse matrix (\code{dgCMatrix} class,
#'               the standard class for sparse numeric matrices in
#'               the \code{Matrix} package.). To convert it into
#'               normal type matrix, use \code{as.matrix()}.}
#'   \item{lambda}{the actual sequence of \code{lambda} values used}
#'   \item{df}{the number of nonzero coefficients for each value
#'             of \code{lambda}.}
#'   \item{dim}{dimension of coefficient matrix}
#'   \item{npasses}{total number of iterations summed over all lambda values}
#'   \item{jerr}{error flag, for warnings and errors, 0 if no error.}
#'   \item{sigma}{actually used penalty parameter in the ADMM or proximal
#'                ADMM algorithm}
#'
#' @author
#' Yuwen Gu <guxxx192@umn.edu>,
#' Hui Zou <zouxx019@umn.edu>
#'
#' Maintainer: Yuwen Gu <guxxx192@umn.edu>
#'
#' @seealso \code{\link{cv.qraenet}}
#'
#' @references Gu, Y., Fan, J., Kong, L., Ma, S. and Zou, H., "ADMM for
#'   high-dimensional sparse penalized quantile regression". To appear in
#'   \emph{Technometrics}.
#'
#' @examples
#' set.seed(1)
#' n <- 100
#' p <- 400
#' x <- matrix(rnorm(n*p), n, p)
#' y <- rnorm(n)
#' tau <- 0.90
#' pf <- abs(rnorm(p))
#' pf2 <- abs(rnorm(p))
#' lambda2 <- 1.0
#' m1 <- qraenet(x = x, y = y, tau = tau, pf = pf, pf2 = pf2,
#'               standardize = FALSE, intercept = FALSE,
#'               lambda2 = lambda2, sigma = 1.0, method = "padmm")
#' m2 <- qraenet(x = x, y = y, tau = tau, pf = pf, pf2 = pf2,
#'               standardize = FALSE, intercept = FALSE,
#'               lambda2 = lambda2, sigma = 0.05, method = "scdadmm")
#'
#' @keywords models regression
#' @export

#-----------------------------------------------------------------------------
qraenet <- function(x, y, nlambda = 100L, method = c("scdadmm", "padmm"),
                    lambda.factor = ifelse(nobs < nvars, 0.05, 0.001),
                    lambda = NULL, lambda2 = 0, pf = rep(1, nvars),
                    pf2 = rep(1, nvars), exclude, dfmax = nvars + 1,
                    vmax = min(dfmax * 1.2, nvars), standardize = TRUE,
                    intercept = TRUE, eps = c(1e-03, 1e-03),
                    maxit = 100000L, tau = 0.5, sigma = 0.05,
                    gamma = 1.0, tol = 1e-7, onlylam = FALSE,
                    verbose = FALSE) {
  #-----------------------------------------------------------------------------
  ## DATA SETUP
  method <- match.arg(method)
  this.call <- match.call()
  y <- drop(y)
  x <- as.matrix(x)
  np <- dim(x)
  nobs <- as.integer(np[1L])
  nvars <- as.integer(np[2L])
  vnames <- colnames(x)
  if (is.null(vnames)) vnames <- paste("V", seq(nvars), sep = "")
  if (NROW(y) != nobs) stop("x and y have different number of observations")
  if (NCOL(y) > 1L) stop("Multivariate response is not supported now")
  #-----------------------------------------------------------------------------
  ## PARAMETER SETUP
  if (length(pf) != nvars)
    stop(paste("Size of L1 penalty factors",
               "does not match",
               "the number of input variables"))
  pf <- as.double(pf)
  if (length(pf2) != nvars)
    stop(paste("Size of L2 penalty factors",
               "does not match",
               "the number of input variables"))
  pf2 <- as.double(pf2)
  if (lambda2 < 0) stop("lambda2 should be non-negative")
  lam2 <- as.double(lambda2)
  maxit <- as.integer(maxit)
  isd <- as.integer(standardize)
  intr <- as.integer(intercept)
  eps <- as.double(eps)
  if (length(eps) != 2L)
    stop("Two tolerances, both absolute and relative, should be provided")
  tol <- as.double(tol)
  dfmax <- as.integer(dfmax)
  vmax <- as.integer(vmax)
  if (!missing(exclude)) {
    jd <- match(exclude, seq(nvars), 0)
    if (!all(jd > 0)) stop("Some excluded variables out of range")
    jd <- as.integer(c(length(jd), jd))
  } else jd <- as.integer(0)
  #-----------------------------------------------------------------------------
  ## LAMBDA AND SIGMA SETUP
  nlam <- as.integer(nlambda)
  if (is.null(lambda)) {
    if (lambda.factor >= 1) stop("lambda.factor should be less than 1")
    flmin <- as.double(lambda.factor)
    ulam <- double(1)
  } else {
    flmin <- as.double(1) # flmin = 1 if user defines lambda
    if (any(lambda < 0)) stop("lambdas should be non-negative")
    ulam <- as.double(rev(sort(lambda)))
    nlam <- as.integer(length(lambda))
  }
  if (length(sigma) == 1) {
    sigma <- rep(sigma, nlam)
  }
  else {
    if (length(sigma) != nlam)
      stop("length of 'sigma' must equal that of 'lambda'")
  }
  sigma <- as.double(sigma)
  if (any(sigma <= 0)) stop("'sigma' must be positive")
  if (method == "padmm") {
    gamma <- as.double(gamma)
    if (gamma <=0 || gamma >= 1.618)
      stop("'gamma' out range; must be in (0, 1.618)")
  }
  onlylam <- as.logical(onlylam)
  verbose <- as.logical(verbose)
  #-----------------------------------------------------------------------------
  fit <- qraenetpath(x, y, nlam, flmin, ulam, isd, intr, eps, dfmax,
                     vmax, jd, pf, pf2, maxit, lam2, tau, nobs,
                     nvars, vnames, sigma, onlylam, tol, method,
                     gamma, verbose)
  if (is.null(lambda) && !onlylam)
    fit$lambda <- lamfix(fit$lambda)
  fit$call <- this.call
  #-----------------------------------------------------------------------------
  class(fit) <- c("qraenet", class(fit))
  fit
}
